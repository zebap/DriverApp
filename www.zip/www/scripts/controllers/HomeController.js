/**
 * @ngdoc function
 * @name conControllers:HomeCtrl
 * @description
 * # HomeCtrl
 * Home controller for duties and ivvites
 */
'use strict';
angular.module('conControllers')
    .controller('HomeCtrl', ['$rootScope', '$scope', '$state', '$ionicLoading', '$filter', '$ionicModal', '$localStorage', 'RateCard', '$sce', '$http', 'ENV', '$ionicSlideBoxDelegate', 'ConUsers', '$ionicHistory', 'BookingInvites', 'Bookings', 'LocalBookings', 'OutstationBookings', '$cordovaGeolocation', '$interval', 'Invoices', '$ionicPopup', 'CustomerDetails', '$cordovaDialogs', 'CancellationReasons', '$ionicPlatform', '$timeout', 'DriverDetails', 'DriverAccount', 'DriverAccountTransactions', 'DriverRechargeTransactions', 'DriverJobDetails', 'DriverJobRequest', 'DriverAllocationReport', 'Cities',

        function($rootScope, $scope, $state, $ionicLoading, $filter, $ionicModal, $localStorage, RateCard, $sce, $http, ENV, $ionicSlideBoxDelegate, ConUsers, $ionicHistory, BookingInvites, Bookings, LocalBookings, OutstationBookings, $cordovaGeolocation, $interval, Invoices, $ionicPopup, CustomerDetails, $cordovaDialogs, CancellationReasons, $ionicPlatform, $timeout, DriverDetails, DriverAccount, DriverAccountTransactions, DriverRechargeTransactions, DriverJobDetails, DriverJobRequest, DriverAllocationReport, Cities) {

            //$rootScope.currentBooking1 = 0;
            $rootScope.todayDate = new Date();

   //var crypt = require('./crypt'); //Use crypt.js
  //  var crypto = require('crypto');
            $scope.currentSlide = "1";
            $rootScope.actualInvoiceId = null;
            $scope.description = 'Recharge Account';
            $rootScope.formattedAddress = 'Select a location';
            $rootScope.hourArray = ENV.hourArray;
            $rootScope.minuteArray = ENV.minuteArray;
            $rootScope.timeArray = ENV.timeArray;
            $rootScope.carTypeArray = ENV.carTypeArray;
            $rootScope.dutyTypeArray = ENV.dutyTypeArray;
            $rootScope.journeyTypeArray = ENV.journeyTypeArray;

            $scope.cancelReasonId = 'Select';
            $scope.selectedCityFlag = true;
            $scope.selectDropLocationFlag = true;
            $scope.reportingTimeValidationFlag = true;
            $scope.showBookingConfirmationFlag = true;
            $scope.repInvalidTimeFlag = true;
            $scope.validReportingTime = null;
            $scope.customerId = null;
            $scope.isPickupLocationPune = false;

            $rootScope.cash = [{
                'desc': 500
            }, {
                'desc': 700
            }, {
                'desc': 1000
            }];
            $scope.selectedOption = $scope.cash[0];


            $scope.stopTimer = function() {
                $timeout.cancel(timer);
            };
            $scope.driverJobConfirmation = function(jobId) {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'Confirmation',
                    template: 'Are you sure you want to Apply for this job?'

                });

                confirmPopup.then(function(res) {
                    if (res) {

                        //  l('You are sure');
                        $scope.applyjob(jobId);
                    } else {
                        //   console.log('You are not sure');
                    }
                });
            }

            $scope.applyjob = function(jobId) {
                $rootScope.show();
                DriverJobRequest.applyDriverJob({
                    jobId: jobId,
                    driverId: $rootScope.driverId,
                    userId: $rootScope.ConUsers.userId,
                    remark: ''
                }, function(suc) {
                    if (suc[0].apply_driver_job === '1') {
                        $cordovaDialogs.alert('already applied to this job.', 'Alert');
                        $scope.getJob();
                        $rootScope.hide();
                    } else {
                        $scope.getJob();
                        $rootScope.hide();
                    }
                    //console.log('suc: ' + JSON.stringify(suc));

                }, function(error) {
                    $rootScope.hide();
                    $scope.getJob();
                    //console.log('error: ' + JSON.stringify(error));
                });
            }

            $scope.showProfile = function() {
                $state.go('profile');
            };
            $scope.showDriverJobs = function() {
                $state.go('driverJobs');
            };
            $scope.getJob = function() {
                $rootScope.show();
                var jobArrayData = [];
                DriverJobDetails.find({
                    filter: {
                        where: {
                            status: 'Open', 
                            location:  $rootScope.operationCity 
                        },
                        include: {
                            relation: 'driverJobRequest',
                            scope: {
                                where: {
                                    driverId: $rootScope.driverId
                                }
                            }
                        },
                        order: 'createdDate DESC',
                    }
                }, function(success) {
                    $rootScope.hide();
                   // console.log('dta: ' + JSON.stringify(success));
                    
                    for(var i=0; i<success.length; i++){
                        var weekDays = [];
                        var dutyHours = '';
                        if(success[i].dutyHours !== null && success[i].dutyTime !== null){
                            dutyHours = success[i].dutyHours +'('+success[i].dutyTime+')';
                        }else if(success[i].dutyHours !== null && success[i].dutyTime === null){
                            dutyHours = success[i].dutyHours
                        }
                         if (success[i].weeklyOff !== null) {
                            for (var j = 0; j < success[i].weeklyOff.length; j++) {
                                if (success[i].weeklyOff[j] === '1') {
                                    
                                    weekDays.push('Monday');
                                }
                                if (success[i].weeklyOff[j] === '2') {
                                    
                                    weekDays.push('Tuesday');
                                }
                                if (success[i].weeklyOff[j] === '3') {
                                    
                                    weekDays.push('Wednesday');
                                }
                                if (success[i].weeklyOff[j] === '4') {
                                    
                                    weekDays.push('Thursday');
                                }
                                if (success[i].weeklyOff[j] === '5') {
                                    
                                    weekDays.push('Friday');
                                }
                                if (success[i].weeklyOff[j] === '6') {
                                    
                                    weekDays.push('Saturday');
                                }
                                if (success[i].weeklyOff[j] === '7') {
                                    
                                    weekDays.push('Sunday');
                                }

                            }
                        }
                        var drvJobId = null;
                        if(success[i].driverJobRequest.length > 0){
                            if(success[i].driverJobRequest[0].driverJobId !== null || success[i].driverJobRequest[0].driverJobId !== ''){
                                drvJobId = success[i].driverJobRequest[0].driverJobId;
                            }
                        }
                        var Days = '' +weekDays;
                        jobArrayData.push({
                            jobId: success[i].id,
                            area: success[i].area,
                            carType: success[i].carType,
                            carName: success[i].vehicleName,
                            dutyHours: dutyHours,
                            weeklyOff: Days.replace('[', '').replace(']', '').replace('"', ''),
                            driverAge: success[i].driverAge,
                            drivingExp: success[i].drivingExperience,
                            outstationDays: success[i].outstationDays,
                            dutyDetails: success[i].dutyType,
                            driverJobId: drvJobId
                        });

                    }
                    $rootScope.driverJob = jobArrayData;
                    
                }, function(err) {
                    $rootScope.hide();
                });
            }
            $ionicModal.fromTemplateUrl('templates/payment-success-message-modal.html', function($ionicPaymentSuccessMsgModal) {
                $scope.paymentSuccessModal = $ionicPaymentSuccessMsgModal;
            }, {

                scope: $scope,

                animation: 'slide-in-left',
                backdropClickToClose: false,
                hardwareBackButtonClose: true
            }).then(function(paymentSuccessModal) {
                $scope.paymentSuccessModal = paymentSuccessModal;

            });

            $scope.slideHasChanged = function(index) {
                //console.log('index' + index)
                $scope.slideIndex = index;
                $scope.currentSlide = $ionicSlideBoxDelegate.currentIndex() + 1;
            };
            $scope.fetchCashDetails = function() {
                Bookings.findOne({
                        filter: {
                            where: {

                                driverId: $rootScope.driverId,
                                status: 'Done'
                                //id: $rootScope.currentBooking.id
                            },
                            include: [{
                                relation: 'invoices',
                                scope: {
                                    include: {
                                        relation: 'invoiceDetails'
                                    }
                                }
                            }, {
                                relation: 'localBookings'
                            }, {
                                relation: 'outstationBookings'
                            }, {
                                relation: 'customerDetails',
                                scope: {
                                    include: {
                                        relation: 'conUsers'
                                    }
                                }
                            }]
                        }
                    },
                    function(response) {
                        //console.log('my bookings : ' + JSON.stringify(response));
                        $scope.myBookings = response;

                    },
                    function(error) {
                       // console.log('error fetching my bookings : ' + JSON.stringify(error));
                    });


            }
            $rootScope.getAccountDetails = function() {
                $rootScope.show();
                $rootScope.noBalance = false;

                DriverDetails.find({
                    filter: {
                        where: {
                            id: $rootScope.driverId
                        },
                        include: [{
                            relation: 'conUsers'


                        }, {
                            relation: 'driverAccount'


                        }]
                    }
                }, function(driverData) {

                    $rootScope.driverDetails = driverData;
                    if ($rootScope.driverDetails[0].driverAccount.length === 0) {
                        $rootScope.balance = 0;
                        $rootScope.noBalance = true;
                    } else {
                        $rootScope.balance = $rootScope.driverDetails[0].driverAccount[0].balance;
                    }
                    $rootScope.hide();
                }, function(err) {
                    $rootScope.hide();
                    $cordovaDialogs.alert('Service Unavailable!', 'Alert');

                  //  console.log('driver all Data ' + JSON.stringify(err));
                });
            };
            $scope.loadTransaction = function() {
                $timeout(function() {
                    $scope.dashboardData();
                    $scope.loadTransactionDetails();
                    $scope.$broadcast('scroll.refreshComplete');

                }, 1000);
            }
            $rootScope.loadTransactionDetails = function() {
                $rootScope.show();
                DriverDetails.find({
                    filter: {
                        where: {
                            id: $rootScope.driverId
                        },
                        include: [{
                            relation: 'conUsers'


                        }, {
                            relation: 'driverAccount'


                        }]
                    }
                }, function(driverData) {
//console.log('data ' +JSON.stringify(driverData));
                    $rootScope.driverDetails = driverData;
                    if ($rootScope.driverDetails[0].driverAccount.length === 0) {
                        $rootScope.balance = 0;
                        $rootScope.noBalance = true;
                    } else {
                        $rootScope.balance = $rootScope.driverDetails[0].driverAccount[0].balance;
                    }
                    $rootScope.limit = 10;
                    $rootScope.getTransactionDetails();
                    $rootScope.hide();
                    
                }, function(err) {
                    $rootScope.hide();
                    $cordovaDialogs.alert('Service Unavailable!', 'Alert');
                   // console.log('driver all Data ' + JSON.stringify(err));
                });

            }
            $scope.openRecharge = function() {
                $state.go('recharge');
            }

            $scope.showPaymentSuccessModal = function() {

                $scope.paymentSuccessModal.show();

            };

            $rootScope.loadMore = function() {
                $rootScope.limit = $rootScope.limit + 10;
                //$rootScope.limit = increamented > $rootScope.cruise.length ? $rootScope.cruise.length : increamented;
                $rootScope.getTransactionDetails();
            };
            $scope.closePaymentSuccessModal = function() {
                $scope.paymentSuccessModal.hide();

                $state.go('AccountSummary');
            };

            var genarateChecksum = function(ver_param, res) {
        genchecksum(ver_param,"your merchant Key", function(err, resData) {
            if (!err) {
                var data = {};
                data.CHECKSUMHASH = resData.CHECKSUMHASH;
                data.ORDER_ID = resData.ORDER_ID;
                data.payt_STATUS = 1;
                res.status(200).send(         //Make sure your response be like this for mobile SDk.
                    data
                );
                res.end();
            } else {
                Logger.error("Error occured");
               
            }
        });
    }
function paramsToString(params, mandatoryflag) {
    var data = '';
    var flag = params.refund ? true : false;
    delete params.refund;
    var tempKeys = Object.keys(params);
    if (!flag) tempKeys.sort();
    tempKeys.forEach(function(key) {
        if (key !== 'CHECKSUMHASH') {
            if (params[key] === 'null') params[key] = '';
            if (!mandatoryflag || mandatoryParams.indexOf(key) !== -1) {
                data += (params[key] + '|');
            }
        }
    });
    return data;
}

function genchecksum(params, key, cb) {
        var flag = params.refund ? true : false;
        var data = paramsToString(params);
 
        crypt.gen_salt(4, function(err, salt) {
            var sha256 = crypto.createHash('sha256').update(data + salt).digest('hex');
            var check_sum = sha256 + salt;
            var encrypted = crypt.encrypt(check_sum, key);
            if (flag) {
                params.CHECKSUM = encodeURIComponent(encrypted);
                params.CHECKSUM = encrypted;
            } else {
                params.CHECKSUMHASH = encodeURIComponent(encrypted);
                params.CHECKSUMHASH = encrypted;
            }
            cb(undefined, params);
        });
    }

            $scope.Recharge = function(amuont, description) {
                var amount = amuont.desc;
                $rootScope.transactionAmount = amount;
                var customer_id = $rootScope.driverId;
                var email = $rootScope.ConUsers.user.email;
                var phone = $rootScope.ConUsers.user.mobileNumber;

                DriverRechargeTransactions.create({

                        driverId: customer_id,
                        accountId: $rootScope.driverDetails[0].driverAccount[0].id,
                        status: 'Initiated',
                        amount: amount,
                        createdBy: $rootScope.ConUsers.user.id,


                    },
                    function(response) {
                        var txn_id = response.id + 'R' + customer_id;
                        $scope.transactionId = Number(response.id);
                        $scope.data = response
                        $scope.data.orderId = txn_id;
                        $scope.data.$save();
                      //  var tid='' + txn_id +'';
                      
                        var cid='' + customer_id+'';
                        var amt='' + amount+'';
                         var CALLBACK_URL = 'http://54.202.79.111:3000/verifychecksum_paytm';
                        var ver_param = { 
  "REQUEST_TYPE": "DEFAULT",
  "MID": "IDCarD52035492281968",
  "ORDER_ID": txn_id,
  "CUST_ID": cid,
  "INDUSTRY_TYPE_ID": "Retail108",
  "CHANNEL_ID": "WAP",
  "TXN_AMOUNT": amt,
  "WEBSITE": "IDCarDriverswap",
  "CALLBACK_URL": CALLBACK_URL,
  "EMAIL":email ,
  "MOBILE_NO": phone
};


                               
                                var url = "http://54.202.79.111:3000";
                                               // var url = 'http://192.168.1.25:3000';
                                                $http.post(url + '/genchecksum_paytm', ver_param).
                                                    success(function(result) {
                                                         console.log('paytm checksum:' + JSON.stringify(result));   
                                                         $scope.checksum= result.CHECKSUMHASH;
                                                         
                                                          //'http://34.217.89.71:3000/verifychecksum_paytm?{\"REQUEST_TYPE\": \"DEFAULT\",\"MID\": \"IDCarD52035492281968\",\"ORDER_ID\":'+ txn_id+',\"CUST_ID\": ' +cid+', \"INDUSTRY_TYPE_ID\": \"Retail108\",\"CHANNEL_ID\": \"WAP\", \"TXN_AMOUNT\":'+ amt+',\"WEBSITE\": \"IDCarDriverswap\", \"EMAIL\":' +email +',\"MOBILE_NO\":'+ phone+', \"CHECKSUMHASH\":'+ $scope.checksum+'}';
                                                         var options = {
  "ENVIRONMENT" : "production",
  "REQUEST_TYPE": "DEFAULT",
  "MID": "IDCarD52035492281968",
  "ORDER_ID": txn_id,
  "CUST_ID": cid,
  "INDUSTRY_TYPE_ID": "Retail108",
  "CHANNEL_ID": "WAP",
  "TXN_AMOUNT": amt,
  "WEBSITE": "IDCarDriverswap",
  "CALLBACK_URL": CALLBACK_URL,
   "EMAIL":email ,
  "MOBILE_NO": phone,
  "CHECKSUMHASH": $scope.checksum
};  
                        //    console.log('Success response is' + JSON.stringify(response));
                        paytm.startPayment(options,
                            function(transactionResponse) {
                                console.log('DriverAccountTransactions response : ' + JSON.stringify(transactionResponse));
                                if (transactionResponse.STATUS == "TXN_SUCCESS") {
                                    DriverRechargeTransactions.driverRechargeOnline({
                                        transactionId: $scope.transactionId
                                    },
                                    function(transactionsuccess) {
                                        // console.log('DriverAccountTransactions response : ' + JSON.stringify(transactionsuccess));
                                        $scope.showPaymentSuccessModal();

                                    },
                                    function(errortransactionsuccess) {
                                       // console.log('DriverAccountTransactions error : ' + JSON.stringify(errortransactionsuccess));
                                    });
         // other details and function after payment transaction
    } else {
        // error code will be available in RESPCODE
        // error list page https://docs.google.com/spreadsheets/d/1h63fSrAmEml3CYV-vBdHNErxjJjg8-YBSpNyZby6kkQ/edit#gid=2058248999
        alert("Transaction Failed for reason " + transactionResponse.RESPMSG);
    }
                                // console.log('payment successfull response : ' + JSON.stringify(transactionResponse));
                                
                                                    },function(error) {

                                                alert("Transaction Failed for reason " + error.RESPMSG);

                                                        DriverRechargeTransactions.findById({
                                        id: $scope.transactionId
                                    },
                                    function(transactionsuccess) {
                                        // console.log('DriverAccountTransactions response : ' + JSON.stringify(transactionsuccess));
                                        $scope.transactionsuccess = transactionsuccess;
                                        $scope.transactionsuccess.status = 'Fail';
                                        $scope.transactionsuccess.updatedDate = new Date();
                                        $scope.transactionsuccess.amount = amount;
                                        $scope.transactionsuccess.updatedBy = $rootScope.ConUsers.user.id;
                                        $scope.transactionsuccess.$save();


                                    },
                                    function(errortransactionsuccesserr) {
                                       // console.log('errortransactionsuccesserr object fail : ' + JSON.stringify(errortransactionsuccesserr));
                                    });
                               // console.log('payment error : ' + JSON.stringify(error));


                                                        // $cordovaDialogs.alert('Error......');
                                                       console.log('Error in updating driver invoiceDetails:' + JSON.stringify(error));
                                                    });

                            },
                            function(error) {
                                
                            });
                    },
                    function(error) {
                       // console.log('Error Create Booking Transaction' + JSON.stringify(error));
                    });

                       // $scope.checksum=genarateChecksum(ver_param);
                    
            }

            $rootScope.getTransactionDetails = function() {
                $rootScope.show();
                var allTransactionData = [];

                var ONE_MONTH = new Date(new Date().setDate(new Date().getDate()-30));
                DriverAccountTransactions.find({

                    filter: {

                        where: {

                            accountId: $rootScope.driverDetails[0].driverAccount[0].id,
                            createdDate: {
                                gt: ONE_MONTH
                            }
                        },
                        order: ['createdDate DESC']

                    }
                }, function(transactionData) {
                    //  console.log('transactionData' + JSON.stringify(transactionData));
                    var description;
                    for (var i = 0; i < transactionData.length; i++) {
                        if (transactionData[i].description === null) {
                            description = '-';
                        } else {
                            description = transactionData[i].description;
                        }

                        allTransactionData.push({
                            transactionDate: transactionData[i].createdDate,
                            description: description,
                            amount: transactionData[i].amount
                        });



                    }
                    $rootScope.transactionDetails = allTransactionData;
                    $scope.data = allTransactionData;
                    $rootScope.cruise = allTransactionData;
                    //   console.log('driver transaction details:' + JSON.stringify(allTransactionData));
                    //createTable();
                    $rootScope.hide();
                }, function(err) {
                    $rootScope.hide();
                    $cordovaDialogs.alert('service unavailable!', 'Alert');

                   // console.log('driver all Data ' + JSON.stringify(err));
                });
            };




            $scope.acceptCash = function(bookingId) {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'Confirmation',
                    template: 'Are you sure you have accepted ' + Math.round($rootScope.cash) + ' cash?' + ' मी ' + Math.round($rootScope.cash) + ' कॅश घेतलेली आहे.'

                });

                confirmPopup.then(function(res) {
                    if (res) {
                        $scope.accept(bookingId);
                    } else {
                    
                    }


                });

            };


            $scope.nextSlide = function() {
                $ionicSlideBoxDelegate.next();

            };

            $scope.previousSlide = function() {
                $ionicSlideBoxDelegate.previous();
            };

            function isActive() {
                ConUsers.findById({
                    id: $rootScope.ConUsers.userId
                }, function(suc) {

                }, function(err) {


                });
            }

            $scope.startDutyConfirmation = function(assign) {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'Confirmation',
                    template: 'Are you sure you want to start Duty?'

                });

                confirmPopup.then(function(res) {
                    if (res) {
                        $scope.startDuty(assign);
                    } else {
                        //   console.log('You are not sure');
                    }
                });
            };

            $scope.startDuty = function(assign) {
                $rootScope.show();
                                    var lat =0;// position.coords.latitude; //here you get latitude
                                    var long =0;// position.coords.longitude; //here you get the longitude
                                    //  console.log('lat long ' + lat + long);
                                  
                                        $rootScope.CurrentLocation = assign.pick_address;//data.data.results[0].formatted_address; //you get the current location here
                                       
                                        $rootScope.currentBooking1 = assign;

                                        Bookings.startDuty({
                                            conuserId: $rootScope.ConUsers.userId,
                                            bookingId: $rootScope.currentBooking1.id,
                                            driverId: $rootScope.driverId,
                                            customerId: assign.customer_id,
                                            pickupAddress: $rootScope.CurrentLocation,
                                            pickupLat: lat,
                                            pickupLong: long
                                        }, function(startDutySuccess) {
                                            //  console.log('startDutySuccess' + JSON.stringify(startDutySuccess));
                                            if (startDutySuccess[0].start_duty === 'Started') {
                                                CustomerDetails.findOne({

                                                    filter: {
                                                        where: {
                                                            id: assign.customer_id

                                                        },
                                                        include: {
                                                            relation: 'conUsers'

                                                        }
                                                    }
                                                }, function(s) {
                                                    //  console.log('customer Information success:' + JSON.stringify(s));
                                                    $rootScope.Information = s;
                                                    var name = $rootScope.Information.conUsers.firstName;
                                                    var number = $rootScope.Information.conUsers.mobileNumber;
                                                    sendSmsToCustomerAtStart(name, number, assign);
                                                    sendSmsToDriverAtStart(assign);
                                                    //var url = "http://192.168.1.18:3000";
                                                    var url = 'http://54.202.79.111:3000';
                                                    var obj = {
                                                        "bookingId": assign.id,
                                                        "requestFrom": "DRIVER_START"
                                                         
                                                    };
                                                    $http.post(url + '/updateInvoiceOnStartAndOffDuty', obj).
                                                    success(function(result) {


                                                    }).
                                                    error(function(error) {
                                                        // $cordovaDialogs.alert('Error......');
                                                      //  console.log('Error in updating driver invoiceDetails:' + JSON.stringify(error));
                                                    });
                                                    $rootScope.hide();
                                                    $state.go('current-duty');
                                                }, function(e) {

                                                });




                                            } else if (startDutySuccess[0].start_duty === 'Inactive') {
                                                $rootScope.hide();
                                                $cordovaDialogs.alert('You are no more active to start this duty! for more details kindly contact 020-67641000.', 'Alert');
                                                $scope.logout();
                                            } else if (startDutySuccess[0].start_duty === 'Cancelled') {
                                                $rootScope.hide();
                                                $cordovaDialogs.alert('This booking has been cancelled! you cannot start this duty', 'Alert');
                                                $scope.loadDataAssign();

                                            } else if (startDutySuccess[0].start_duty === 'On Duty') {
                                                $rootScope.hide();
                                                $cordovaDialogs.alert('This duty is already started!', 'Alert');
                                                $scope.loadDataAssign();

                                            } else if (startDutySuccess[0].start_duty === 'Done') {
                                                $rootScope.hide();
                                                $cordovaDialogs.alert('This duty is already done!', 'Alert');
                                                $scope.loadDataAssign();
                                            } else {

                                            }



                                        }, function(startDutyError) {
                                           // console.log('startDutyError' + JSON.stringify(startDutyError));
                                        });


                        
            $rootScope.hide();

            };
            $scope.logout = function() {
                
                $ionicHistory.clearHistory();
                $ionicHistory.clearCache();
                delete $localStorage.user;
                $rootScope.ConUsers = undefined;
                $ionicHistory.nextViewOptions({
                    disableBack: true

                });

                //   console.log('local storage: ' + JSON.stringify($localStorage.user));
                $state.go('login');
            };

            function sendSmsToCustomerAtStart(name, number, assign) {

                var time = $filter('date')(new Date(), 'hh:mm:ss a');
                var date = $filter('date')(new Date(), 'dd/MM/yyyy');

                var customerName = name;
                var msg = 'Hi ' + customerName + ',%0aThe journey has started for Booking Id:' + assign.id + ' @ ' + time + ' Dated on ' + date + '. Stay on the app to track this ride. Have a safe Journey';
                
                ConUsers.sendSMS({
                    mobileNumber: number,
                    msg: msg
                }, function(mgssuccess) {
                    // console.log('msg sent successfully:' + JSON.stringify(mgssuccess));
                }, function(error) {
                   // console.log('error in sending msg: ' + JSON.stringify(error));

                });


            }

            function sendSmsToDriverAtStart(assign) {
                var time = $filter('date')(new Date(), 'hh:mm:ss a');
                var date = $filter('date')(new Date(), 'dd/MM/yyyy');
                var driverName = $rootScope.ConUsers.user.firstName;
                var msg = 'Hi ' + driverName + ',%0aThe journey has started for Booking Id: ' + assign.id + ' @ ' + time + ' Dated on ' + date + '. Have a safe Journey';
                
                ConUsers.sendSMS({
                    mobileNumber: $rootScope.ConUsers.user.mobileNumber,
                    msg: msg
                }, function(mgssuccess) {
                    // console.log('msg sent successfully:' + JSON.stringify(mgssuccess));
                }, function(error) {
                   // console.log('error in sending msg: ' + JSON.stringify(error));

                });

            }

            $scope.offDutyConfirmation = function(myBookings) {
                console.log(' myBookings is: ' +JSON.stringify(myBookings));
                var confirmPopup = $ionicPopup.confirm({
                    title: 'Confirmation',
                    template: 'Are you sure you want to Off Duty?'

                });

                confirmPopup.then(function(res) {
                    if (res) {

                        //   console.log('You are sure');
                        offDuty(myBookings);
                    } else {
                        // console.log('You are not sure');
                    }
                });
            };

            function offDuty(myBookings) {
                if(myBookings[0].is_round_trip){
                                 $rootScope.show();
            $rootScope.currentBookingId = myBookings[0].booking_id;

                                        Bookings.offDutyForDriver({
                                            bookingId: $rootScope.currentBookingId,
                                            dropLocation: myBookings[0].drop_address,
                                            dropLat: myBookings[0].drop_lat,
                                            dropLong: myBookings[0].drop_long,
                                            updatedBy: $rootScope.ConUsers.user.id
                                        }, function(offDutySuccess) {
                                            // console.log('offDutySuccess' + JSON.stringify(offDutySuccess));
                                            if (offDutySuccess[0].off_duty_for_driver === 'Success') {

                                                //var url = "http://192.168.1.18:3000";
                                                var url = 'http://54.202.79.111:3000';

                                                var obj = {
                                                    "bookingId": $rootScope.currentBookingId,
                                                    "requestFrom": "DRIVER_OFF"
                                                    
                                                };



                                                $http.post(url + '/updateInvoiceOnStartAndOffDuty', obj).
                                                success(function(result) {
                                                    // console.log('Updated invoices successfully' + JSON.stringify(result));
                                                    Bookings.findOne({

                                                        filter: {
                                                            where: {
                                                                id: $rootScope.currentBookingId
                                                                //driverId: $rootScope.driverId

                                                            },
                                                            include: [{
                                                                relation: 'outstationBookings'
                                                            }, {
                                                                relation: 'invoices'
                                                            }]
                                                        }
                                                    }, function(response) {
                                                        //  console.log(' booking ' + JSON.stringify(response));
                                                        $rootScope.ammount = response.invoices[0].netAmount;
                                                        var booking = response;

                                                        var name = myBookings[0].first_name;
                                                        var number = myBookings[0].mobile_number;
                                                        sendSmsToCustomerAtOff(name, number, booking, $rootScope.ammount);
                                                        sendSmsToDriverAtOff(booking, $rootScope.ammount);
                                                         $scope.loadDatacurrent();
                                                        $rootScope.currentBooking1 = 0;
                                                    }, function(error) {
                                                       // console.log(' booking ' + JSON.stringify(response));

                                                    });






                                                }).
                                                error(function(error) {
                                                    //$cordovaDialogs.alert('Error......');
                                                   // console.log('Error in updating driver geolocation:' + JSON.stringify(error));
                                                });
                                                $rootScope.hide();
                                                //$state.go('dashboard');


                                            } else if (offDutySuccess[0].off_duty_for_driver === 'Done') {
                                                $cordovaDialogs.alert('This duty is already done', 'Alert');
                                                $scope.loadDatacurrent();
                                            } else {
                                                //do nothing
                                            }



                                        }, function(offDutyErr) {
                                           // console.log('offDutyErr' + JSON.stringify(offDutyErr));
                                        });
                }else{
                                     $rootScope.show();
                                    var lat = 0;//position.coords.latitude //here you get latitude
                                    var long =0;// position.coords.longitude //here you get the longitude
                                 $rootScope.CurrentLocationAtOff = myBookings[0].drop_address;
                                        $rootScope.currentBookingId = myBookings[0].booking_id;

                                        Bookings.offDutyForDriver({
                                            bookingId: $rootScope.currentBookingId,
                                            dropLocation: $rootScope.CurrentLocationAtOff,
                                            dropLat: lat,
                                            dropLong: long,
                                            updatedBy: $rootScope.ConUsers.user.id
                                        }, function(offDutySuccess) {
                                            // console.log('offDutySuccess' + JSON.stringify(offDutySuccess));
                                            if (offDutySuccess[0].off_duty_for_driver === 'Success') {

                                                //var url = "http://192.168.1.18:3000";
                                                var url = 'http://54.202.79.111:3000';

                                                var obj = {
                                                    "bookingId": $rootScope.currentBookingId,
                                                    "requestFrom": "DRIVER_OFF"
                                                    
                                                };



                                                $http.post(url + '/updateInvoiceOnStartAndOffDuty', obj).
                                                success(function(result) {
                                                    // console.log('Updated invoices successfully' + JSON.stringify(result));
                                                    Bookings.findOne({

                                                        filter: {
                                                            where: {
                                                                id: $rootScope.currentBookingId
                                                                //driverId: $rootScope.driverId

                                                            },
                                                            include: [{
                                                                relation: 'outstationBookings'
                                                            }, {
                                                                relation: 'invoices'
                                                            }]
                                                        }
                                                    }, function(response) {
                                                        //  console.log(' booking ' + JSON.stringify(response));
                                                        $rootScope.ammount = response.invoices[0].netAmount;
                                                        var booking = response;

                                                        var name = myBookings[0].first_name;
                                                        var number = myBookings[0].mobile_number;
                                                        sendSmsToCustomerAtOff(name, number, booking, $rootScope.ammount);
                                                        sendSmsToDriverAtOff(booking, $rootScope.ammount);

                                                        $rootScope.currentBooking1 = 0;
                                                    }, function(error) {
                                                       // console.log(' booking ' + JSON.stringify(response));

                                                    });



                                                }).
                                                error(function(error) {
                                                    //$cordovaDialogs.alert('Error......');
                                                   // console.log('Error in updating driver geolocation:' + JSON.stringify(error));
                                                });
                                                $rootScope.hide();
                                                //$state.go('dashboard');


                                            } else if (offDutySuccess[0].off_duty_for_driver === 'Done') {
                                                $cordovaDialogs.alert('This duty is already done', 'Alert');
                                                $scope.loadDatacurrent();
                                            } else {
                                                //do nothing
                                            }



                                        }, function(offDutyErr) {
                                           // console.log('offDutyErr' + JSON.stringify(offDutyErr));
                                        });




                                     }

               

            };

            function sendSmsToCustomerAtOff(name, number, booking, ammount) {


                var endDate = $filter('date')(new Date(), 'dd-MM-yyyy');
                var relTime = $filter('date')(new Date(), 'hh:mm:ss a');
                var startDate = $filter('date')(booking.reportingDate, 'dd-MM-yyyy');
                var rptTime = $scope.converToTwelveHour(booking.reportingTime);

                var billedAmmount = Math.round((ammount) * 100) / 100;

                var customerName = name;
                var msg = 'Dear ' + customerName + ',%0aYour Duty(ID: ' + booking.id + ') %0aStarted on: ' + startDate + ' @ ' + rptTime + '%0aEnded on: ' + endDate + ' @ ' + relTime + '%0aTotal billed amount: Rs.' + billedAmmount + '/-. %0aFor details download app (https://goo.gl/XFPFwh). For inquiries call 020-67641000. %0aThank you, %0aIndian Drivers.';
                
                ConUsers.sendSMS({
                    mobileNumber: number,
                    msg: msg
                }, function(mgssuccess) {
                    //  console.log('msg sent successfully:' + JSON.stringify(mgssuccess));
                }, function(error) {
                   // console.log('error in sending msg: ' + JSON.stringify(error));

                });

            }

            function sendSmsToDriverAtOff(booking, ammount) {
                var endDate = $filter('date')(new Date(), 'dd-MM-yyyy');
                var relTime = $filter('date')(new Date(), 'hh:mm:ss a');
                var startDate = $filter('date')(booking.reportingDate, 'dd-MM-yyyy');
                var rptTime = $scope.converToTwelveHour(booking.reportingTime);

                var billedAmmount = Math.round((ammount) * 100) / 100;
                var driverName = $rootScope.ConUsers.user.firstName;
                var msg = 'Dear ' + driverName + ',%0aYour Duty(ID: ' + booking.id + ') ended on ' + endDate + ' @ ' + relTime + '. started was on ' + startDate + ' @ ' + rptTime + ' Your total billed amount is Rs.' + billedAmmount + '/-. For details download app (https://goo.gl/Z5tDgU). For inquiries call 020-67641000 Thank you Indian Drivers .';
                
                ConUsers.sendSMS({
                    mobileNumber: $rootScope.ConUsers.user.mobileNumber,
                    msg: msg
                }, function(mgssuccess) {
                    //  console.log('msg sent successfully:' + JSON.stringify(mgssuccess));
                }, function(error) {
                   // console.log('error in sending msg: ' + JSON.stringify(error));

                });
            }

            $ionicModal.fromTemplateUrl('templates/booking-cancelation-message-modal.html', function($ionicBookingCancelMsgModal) {
                $scope.bookingCancelMsgModal = $ionicBookingCancelMsgModal;
            }, {
                // Use our scope for the scope of the modal to keep it simple
                scope: $scope,
                // The animation we want to use for the modal entrance
                animation: 'slide-in-left',
                backdropClickToClose: false,
                hardwareBackButtonClose: true
            }).then(function(bookingCancelMsgModal) {
                $scope.bookingCancelMsgModal = bookingCancelMsgModal;
                // console.log('In $ionicModal thanks msg Modal');
            });



            $scope.closeBookingCancelMsg = function() {
                $scope.bookingCancelMsgModal.hide();
                $state.go('dashboard');
                //$rootScope.menuComponentId = 'bookings-left';
            };

            $scope.showConfirmation = function(assign) {

                var confirmPopup = $ionicPopup.confirm({
                    title: 'Confirmation',
                    template: 'Are you sure you want to Cancel Duty?'

                });

                confirmPopup.then(function(res) {
                    if (res) {

                        // console.log('You are sure');
                        cancelDuty(assign);
                    } else {
                        //  console.log('You are not sure');
                    }
                });
            };

            function cancelDuty(assign) {
                $rootScope.show();
                // console.log('cancelduty data:' + JSON.stringify(assign));
                $rootScope.bookingData = assign;
                //  console.log('I am in cancel Booking');

                Bookings.findById({
                    id: assign.id
                }, function(success) {
                    //   console.log('booking : ' + JSON.stringify(success));
                    if (success.status === 'Line Up') {
                        if (Number(success.driverId) === $rootScope.driverId) {

                            Bookings.driverCancelDutyNew1({
                                driverId: $rootScope.driverId,
                                bookingId: assign.id,
                                 userId: $rootScope.ConUsers.user.id 
                            }, function(Success) {
                                //  console.log('cancel duty: ' + JSON.stringify(Success));
                                if (Success[0].driver_cancel_duty1 == 'Cancelled') {
                                     DriverAllocationReport.createAllocationHistory({
                                        bookingId: assign.id,
                                        driverId: $rootScope.driverId,
                                        userId: $rootScope.ConUsers.user.id,
                                        allocationStatus: 'Deallocation'
                                    }, function(success) {
                                        
                       
                                    //  console.log('suucess cancel duty: ' + JSON.stringify(Success));

                                    //smsToCustomerAtCancelDuty(name, number, assign);
                                    // sendSmsToDriverAtCancelDuty(assign);
                                    // sendSmsToAuthorities(assign);
                                    $rootScope.hide();
                                    $cordovaDialogs.alert('Your duty has been cancelled sucessfully.', 'Alert');
                                    $state.go('dashboard');
                                     }, function(error) {
                      //  console.log('created allocation error' + JSON.stringify(error));
                    });


                                } else if (Success[0].driver_cancel_duty1 == 'Allocation Error') {
                                    $rootScope.hide();
                                    $cordovaDialogs.alert('This duty is not valid any more.', 'Alert');
                                    $scope.loadDataAssign();
                                } else {
                                    // do nothing
                                }

                            }, function(err) {

                            });
                        } else {
                            $cordovaDialogs.alert('This duty is no more valid. Already cancelled!', 'Alert');
                            $scope.loadDataAssign();
                        }

                    } else if (success.status === 'New Booking') {
                        $cordovaDialogs.alert('This duty is no more valid.', 'Alert');
                        $scope.loadDataAssign();

                    } else if (success.status === 'On Duty') {
                        $cordovaDialogs.alert('This duty is already started, unable to cancel.', 'Alert');
                        $scope.loadDataAssign();
                    } else {
                        $scope.loadDataAssign();
                    }




                }, function(error) {});


                //
            };
             $scope.CallNumber = function(number){ 

       console.log('n  :' +number);
       var num ='+91' +number
    window.plugins.CallNumber.callNumber(onSuccess, onError, num, false);
    function onSuccess(result){
  console.log("Success:"+result);
}

function onError(result) {
  console.log("Error:"+result);
}
  };

            function sendSmsToAuthorities(assign) {
                $scope.numbers = ['9028123366', '9225513111', '9225585200'];
                
                var reportingDate = $filter('date')(new Date(assign.reporting_date), 'dd-MM-yyyy');
                var msg = 'Hi ' + ',%0aThe Driver ' + $rootScope.ConUsers.user.firstName + ' ' + $rootScope.ConUsers.user.lastName + '(' + $rootScope.driverId + ') has cancelled the Booking ID:' + assign.id + ' dated on ' + reportingDate + ' @ ' + assign.reporting_time + '.';
                
                ConUsers.sendSMS({
                    mobileNumber: $scope.numbers,
                    msg: msg
                }, function(mgssuccess) {
                    //  console.log('msg sent successfully:' + JSON.stringify(mgssuccess));
                }, function(error) {
                  //  console.log('error in sending msg: ' + JSON.stringify(error));

                });


            }

            function smsToCustomerAtCancelDuty(name, number, assign) {
                var msg = 'Hi ' + name + ',%0aWe are replacing the driver assigned to you for the Booking Id:' + assign.id + '. New Driver details will be messaged shortly. For queries, please reach us on 020-67641000 or info@indian-drivers.com.';
                var data = "";
                
                ConUsers.sendSMS({
                    mobileNumber: number,
                    msg: msg
                }, function(mgssuccess) {
                    // console.log('msg sent successfully:' + JSON.stringify(mgssuccess));
                }, function(error) {
                  //  console.log('error in sending msg: ' + JSON.stringify(error));

                });

            };

            function sendSmsToDriverAtCancelDuty(assign) {

                var driverName = $rootScope.ConUsers.user.firstName;
                var msg = 'Hi ' + driverName + ',%0aYou have cancelled the duty allocated to you Booking Id:' + assign.id + '. For queries, please reach us on 020-67641000 or info@indian-drivers.com';
                
                ConUsers.sendSMS({
                    mobileNumber: $rootScope.ConUsers.user.mobileNumber,
                    msg: msg
                }, function(mgssuccess) {
                    // console.log('msg sent successfully:' + JSON.stringify(mgssuccess));
                }, function(error) {
                   // console.log('error in sending msg: ' + JSON.stringify(error));

                });

            }
            $scope.getRatecard = function() {
                $state.go('rate-card');
            }
            $scope.accept = function(bookingId) {
                $rootScope.show();
                //  console.log('bookingId ***' + JSON.stringify(bookingId));
                Bookings.paidDutyFunction({
                    bookingId: bookingId,
                    paymentMethod: 'D',
                    userId: $rootScope.ConUsers.user.id
                }, function(paymentSuccess) {
                    $rootScope.hide();
                    if (paymentSuccess[0].paid_duty_function === '0') {
                       /* $scope.loadDatacurrent();*/
                      $state.go('today_duty_invite');

                    }
                    //  console.log('paymentSuccess ' + JSON.stringify(paymentSuccess));
                }, function(paymentErr) {
                    $rootScope.hide();
                   // console.log('paymentErr ' + JSON.stringify(paymentErr));
                })
            }

            $scope.currentDuty = function() {
                //  console.log('$rootScope.driverId ***' + JSON.stringify($rootScope.driverId));
                //$rootScope.offDutyFlag = false;
                $rootScope.show();

                Bookings.getDriverCurrentDuty({
                    driverId: $rootScope.driverId
                }, function(currentDutySuccess) {
                    console.log('currentDutySuccess ***' + JSON.stringify(currentDutySuccess));
                    $rootScope.currentBookingDetails = currentDutySuccess;
                    if (currentDutySuccess.length > 0) {
                        if (currentDutySuccess[0].booking_id !== null) {
                            $rootScope.bookingId = currentDutySuccess[0].booking_id;
                            $rootScope.cash = currentDutySuccess[0].net_amount;
                            $rootScope.customerName = currentDutySuccess[0].first_name + ' ' + currentDutySuccess[0].last_name;
                            var currentTime = currentDutySuccess[0].relieving_time;
                            $scope.CurrentTimeHour = currentTime.split(':')[0];
                            //console.log('Current Time in Hour: ' + $scope.CurrentTimeHour);

                        } else {
                            $scope.currentBookingDetails = 0;
                        }


                    }


                    $rootScope.hide();

                }, function(currentDutyError) {
                   // console.log('currentDutyError ***' + JSON.stringify(currentDutyError));
                });

            };
            $scope.rateCardData = function() {
                 Cities.findOne({
                        filter:{
                           where:{
                            cityName:$rootScope.operationCity
                        } 
                        }
                        
                        },function(s){
                            $rootScope.operationCityId=s.id;
                                console.log(s);

                                RateCard.findOne({
                        filter: {
                            where: {
                                type: 'Driver',
                                operationCityId:$rootScope.operationCityId
                            }
                        }
                    },
                    function(rateCardsuc) {

                        $scope.rateCardDetail = $sce.trustAsHtml(rateCardsuc.rateCardHtml);

                    },
                    function(ratecarderr) {

                    });
                        },function(r){
                    });
                
            }

            $scope.showRateCard = function() {
                $state.go('rate-card');
            }

            $scope.showConfirm = function(invite) {
                $scope.isDisabled = true;
                var confirmPopup = $ionicPopup.confirm({
                    title: 'Confirmation',
                    template: 'Are you sure you want to Accept the Duty?'

                });

                confirmPopup.then(function(res) {
                    if (res) {

                        //console.log('You are sure');
                        AcceptDuty(invite);
                    } else {
                        $scope.isDisabled = false;
                        //console.log('You are not sure');
                    }
                });
            };
            /* $scope.$on('$ionicView.enter', function(event, data) {
                                   // Code you want executed every time view is opened
                                   console.log('Opened!');

                                   var stateName = data.stateName;
                                   if (stateName === 'assigned-duty') {
                                     $state.go('assigned-duty');  
                                   }

                               });*/

            function AcceptDuty(invite)

            {

                $rootScope.show();
                $rootScope.customer =undefined;
                $rootScope.booking = undefined;
                //console.log('invites:' + JSON.stringify(invite));
                Bookings.acceptDuty({

                        driverId: $rootScope.driverId,
                        bookingId: invite.booking_id,
                        oldDriverId: '0'

                    }, function(res) {

                        //console.log('Accepted success' + JSON.stringify(res));
                        if (res[0].accept_duty == 'Already Allocated to other duty on the same day') {
                            $rootScope.hide();
                            $cordovaDialogs.alert('You are already allocated to other duty on the same day.', 'Alert');
                            $scope.loadDataInvitesToday();
                        } else if (res[0].accept_duty == 'Allocation Error') {
                            $rootScope.hide();
                            $cordovaDialogs.alert('This duty is not valid any more.', 'Alert');
                            $scope.loadDataInvitesToday();

                        } else if (res[0].accept_duty == 'Please Recharge Your Account to Accept this Duty') {
                            $rootScope.hide();
                            var alertPopup = $ionicPopup.alert({
                                title: 'Alert',
                                template: 'Please Recharge Your Account to Accept this Duty. for queries contact 020-67641000.'
                            });

                            alertPopup.then(function(res) {
                                $state.go('recharge');
                                //$scope.loadDataInvitesToday();
                                // Custom functionality....
                            });



                        } else if (res[0].accept_duty == 'Account Error') {
                            $rootScope.hide();
                            $cordovaDialogs.alert('Your account does not exist.', 'Alert');
                            $scope.loadDataInvitesToday();
                        } else if (res[0].accept_duty == 'Driver Block') {
                            $rootScope.hide();

                            $cordovaDialogs.alert('You are no more active to accept this duty! for more Details kindly contact 020-67641000.', 'Alert');
                            $scope.loadDataInvitesToday();
                        } else if (res[0].accept_duty == 'License Expired') {
                            $rootScope.hide();

                            $cordovaDialogs.alert('Your Driving License is expired, Please submit renewed license copy to Indian Drivers office(020-67641000) to Accept Duty.', 'Alert');
                            $scope.loadDataInvitesToday();
                        } else if (res[0].accept_duty == 'Kindly Update Your License') {
                            $rootScope.hide();

                            $cordovaDialogs.alert('Kindly Update Your License', 'Alert');
                            $scope.loadDataInvitesToday();
                        } else if (res[0].accept_duty == 'License Expire Soon') {
                            var currDate = new Date();
                            var licenseTrDate = null;
                            var licenseNtDate = null;
                            var licenseExpiredDate = null;


       $timeout(function() {

                        $ionicLoading.hide();
                    }, 5000);



                            if ($rootScope.driverLicenseData.trDate !== null) {
                                licenseTrDate = new Date($rootScope.driverLicenseData.trDate);
                            }
                            if ($rootScope.driverLicenseData.ntDate !== null) {
                                licenseNtDate = new Date($rootScope.driverLicenseData.ntDate);
                            }
                            if (licenseTrDate !== null && licenseNtDate !== null) {

                                if (licenseTrDate < licenseNtDate) {
                                    licenseExpiredDate = $filter('date')(licenseTrDate, 'dd/MM/yyyy');
                                } else {
                                    licenseExpiredDate = $filter('date')(licenseNtDate, 'dd/MM/yyyy');
                                }
                            } else if (licenseNtDate !== null) {
                                licenseExpiredDate = $filter('date')(licenseNtDate, 'dd/MM/yyyy');
                            } else if (licenseTrDate !== null) {
                                licenseExpiredDate = $filter('date')(licenseTrDate, 'dd/MM/yyyy');
                            } else {

                            }


                            $cordovaDialogs.alert('Your mobile app will be blocked soon, as driving license expiring on ' + licenseExpiredDate + ', please renew and submit copy to Indian Drivers office.', 'Alert');
                            CustomerDetails.findOne({

                                filter: {
                                    where: {
                                        id: invite.customer_id

                                    },
                                    include: {
                                        relation: 'conUsers'

                                    }
                                }
                            }, function(s) {
                                var customer = s;
                                    $rootScope.custInformation = s;
                                    $rootScope.customer = s.conUsers;
                                //console.log('customer Information success:' + JSON.stringify(s));
                                Bookings.findOne({
                                    filter: {
                                        where: {
                                            id: invite.booking_id

                                        },
                                        include: [{
                                            relation: 'localBookings'

                                        }, {
                                            relation: 'outstationBookings'
                                        }]
                                    }
                                }, function(booking) {
                                    $rootScope.booking = booking;
                                    //console.log('booking success: ' + JSON.stringify(booking));
                                     DriverAllocationReport.createAllocationHistory({
                                        bookingId: invite.booking_id,
                                        driverId: $rootScope.driverId,
                                        userId: $rootScope.ConUsers.user.id,
                                        allocationStatus: 'Allocation'
                                    }, function(success) {
                        
                                    var customer = $rootScope.customer
                                    var driver = $rootScope.ConUsers.user;
                                    var booking = $rootScope.booking;



                                        

                                    $timeout(function() {

                                        $ionicLoading.hide();
                                    }, 5000);
                                                      








                                    smsToCustomerAtAccept(customer, driver, booking);
                                    smsToDriverAtAccept(customer, driver, booking);
                                    $rootScope.hide();
                                                $state.go('assigned-duty');
                                                 }, function(error) {
                                  //  console.log('created allocation error' + JSON.stringify(error));
                                });
                                }, function(bookingerr) {
                                    $rootScope.hide();
                                  //  console.log('error :' + JSON.stringify(error));
                                });

                            }, function(e) {
                                $rootScope.hide();
                               // console.log('error fetching customer:' + JSON.stringify(e));
                            });

                            $rootScope.hide();
                            $state.go('assigned-duty');
                            //$scope.loadDataInvitesToday();
                        } else if (res[0].accept_duty == 'Please complete your lineup duty') {
                            $rootScope.hide();

                            $cordovaDialogs.alert('Your previous duty is still in lineup. please contact Office.', 'Alert');
                            //$scope.loadDataInvitesToday();

                        } else if (res[0].accept_duty == 'Accepted') {


                            CustomerDetails.findOne({

                                filter: {
                                    where: {
                                        id: invite.customer_id

                                    },
                                    include: {
                                        relation: 'conUsers'

                                    }
                                }
                            }, function(s) {
                                var customer = s;
                                    $rootScope.custInformation = s;
                                    $rootScope.customer = s.conUsers;
                                //console.log('customer Information success:' + JSON.stringify(s));
                                Bookings.findOne({
                                    filter: {
                                        where: {
                                            id: invite.booking_id

                                        },
                                        include: [{
                                            relation: 'localBookings'

                                        }, {
                                            relation: 'outstationBookings'
                                        }]
                                    }
                                }, function(booking) {
                                    $rootScope.booking = booking;
                                    //console.log('booking success: ' + JSON.stringify(booking));
                                     DriverAllocationReport.createAllocationHistory({
                                        bookingId: invite.booking_id,
                                        driverId: $rootScope.driverId,
                                        userId: $rootScope.ConUsers.user.id,
                                        allocationStatus: 'Allocation'
                                    }, function(success) {
                                    var customer = $rootScope.customer
                                    var driver = $rootScope.ConUsers.user;
                                    var booking = $rootScope.booking;
                                     
                                    smsToCustomerAtAccept(customer, driver, booking);
                                    smsToDriverAtAccept(customer, driver, booking);
                                    $rootScope.hide();
                                    $state.go('assigned-duty');
                                    }, function(error) {
                                  //  console.log('created allocation error' + JSON.stringify(error));
                                });
                                }, function(bookingerr) {
                                    $rootScope.hide();
                                   // console.log('error :' + JSON.stringify(error));
                                });

                            }, function(e) {
                                $rootScope.hide();
                               // console.log('error fetching customer:' + JSON.stringify(e));
                            });
                            $rootScope.hide();
                            $state.go('assigned-duty');

                        } else {
                            $rootScope.hide();
                            //do nothing
                        }

                        // $state.go('dashboard');
                    },
                    function(error) {
                        $rootScope.hide();
                       // console.log('fail' + JSON.stringify(error));
                    });



            };

            function smsToCustomerAtAccept(customer, driver, booking) {
                var rptTime = booking.reportingTime;
                var dateValue = new Date(booking.reportingDate);
                var rptDate = $filter('date')(new Date(dateValue), 'dd-MM-yyyy');
                var msg = 'Hi ' + customer.firstName + ',%0aDriver:' + driver.firstName + ' ' + driver.mobileNumber + ')' + ' has been allocated for Booking Id:' + booking.id + ', dated ' + rptDate + ', Time ' + rptTime + ' For queries, please reach us on 020-67641000 or info@indian-drivers.com.';
               
                ConUsers.sendSMS({
                    mobileNumber: customer.mobileNumber,
                    msg: msg
                }, function(mgssuccess) {

                    //console.log('msg sent successfully:' + JSON.stringify(mgssuccess));
                }, function(error) {
                    console.log('error in sending msg: ' + JSON.stringify(error));

                });


            };

            function smsToDriverAtAccept(customer, driver, booking) {
                //console.log('rh: '+JSON.stringify(booking.localBookings[0].releavingDuration));

                var rptTime = booking.reportingTime;
                if (booking.isOutstation === true) {
                    var dutyType = 'Outstation';
                } else {
                    var dutyType = 'Local';
                }
                if (booking.carType === 'M') {
                    var carType = 'Manual';
                } else if (booking.carType === 'A') {
                    var carType = 'Automatic';
                } else {
                    var carType = 'Luxury';
                }
                if (booking.landmark === 'null') {
                    var landmark = '';
                } else {
                    var landmark = booking.landmark + ', ';
                }
                if (booking.isRoundTrip === true) {
                    var journeyType = 'Round Trip';
                    var dropadd = '';
                } else {
                    var journeyType = 'OneWay Trip'
                    var dropadd = ' Drop Address: ' + booking.dropAddress;
                }
                if (booking.isOutstation === false) {
                    var relHour = ' Releiving Hours: ' + (booking.localBookings[0].releavingDuration / 60);
                } else {
                    var dateValue = booking.outstationBookings[0].releavingDate;
                    var relTime = booking.outstationBookings[0].releavingTime;
                    var relDate = $filter('date')(new Date(dateValue), 'dd-MM-yyyy');
                    var relHour = ' Releiving Date And Time : ' + relDate + ' ' + relTime;
                }
                var picadd = landmark + booking.pickAddress;
                var dateValue1 = booking.reportingDate;
                var rptDate = $filter('date')(new Date(dateValue1), 'dd-MM-yyyy');

                var msg = 'Hi ' + driver.firstName + ',%0aYour Booking ID: ' + booking.id + ' Duty Type: ' + dutyType +' ' + journeyType + ' Car: ' + carType + ' Reporting Date And Time: ' + rptDate + ' ' + rptTime + relHour + '. Pick up Address: ' + picadd + dropadd + '. Customer: ' + customer.firstName + ', ' + customer.mobileNumber;
                
                ConUsers.sendSMS({
                    mobileNumber: driver.mobileNumber,
                    msg: msg
                }, function(mgssuccess) {
                    //console.log('msg sent successfully:' + JSON.stringify(mgssuccess));
                }, function(error) {
                   // console.log('error in sending msg: ' + JSON.stringify(error));

                });

            };
            $scope.dashboard = function() {
                $state.go('dashboard');

            }

           $scope.dashboardData = function() {
                $rootScope.show();
                ConUsers.findById({
                        id: $rootScope.ConUsers.user.id
                    },
                    function(response) {
                        //console.log('fetchUserDetails success : ' + JSON.stringify(response));
                        $scope.user = response;
                        DriverDetails.findOne({
                            filter: {
                                where: {
                                    conuserId: $rootScope.ConUsers.user.id
                                }
                            }

                        }, function(success) {
                            $rootScope.ondutyflag = false;
                              $rootScope.freeflag = false;
                                $rootScope.assigndutyflag = false;
                            //console.log('success driver details: ' + JSON.stringify(success));
                            $rootScope.hide();
                            $rootScope.driverId = success.id;
                            $scope.drivers = success;
                            $rootScope.driverLicenseData = success;
                            //console.log('date: ' + JSON.stringify($rootScope.ConUsers.user.id));
                            $scope.trDate = $filter('date')($scope.drivers.trDate, 'dd/MM/yyyy');
                            $scope.ntDate = $filter('date')($scope.drivers.ntDate, 'dd/MM/yyyy');
                                                             Bookings.getDriverStatus({
                                                                driverId:     $rootScope.driverId
                                                                 }, function(success) {
                                                         console.log(' booking ' + JSON.stringify(success));
                                                          
                                                         if (success[0].get_driver_status === 'On Duty') {
                                                                       $rootScope.ondutyflag = true;
                                                                        $rootScope.freeflag = false;
                                                                        $rootScope.assigndutyflag = false;
                                                                       /*if(success[i].status === 'On Duty'){
                                                                        $rootScope.currentBooking1 = success[i];
                                                                       }*/

                                                        }
                                                        else if (success[0].get_driver_status === 'Line Up') {
                                                                   $rootScope.ondutyflag = false;
                                                                   $rootScope.freeflag = false;
                                                                    $rootScope.assigndutyflag = true;
                                                                   $rootScope.assigndutystatus = success[0].get_driver_status;

                                                            }
                                                            else {
                                                                      $rootScope.freeflag = true;
                                                                       $rootScope.assigndutyflag = false;
                                                                    $rootScope.ondutyflag = false;

                                                            }
                                                        
                                                           Bookings.find({

                                                               filter: {
                                                                where: {
                                                                driverId:     $rootScope.driverId
                                                                }
                                                             }
                                                        }, function(success) {
                                                          for( var i = 0; i < success.length; i++){ 
                                                                       if(success[i].status === 'On Duty'){
                                                                        $rootScope.currentBooking1 = success[i];
                                                                       } 
                                                                     }
                                                                   }, function(error) {
                                                          });
 
                                                          

                                                    }, function(error) {
                                                        //.log(' booking ' + JSON.stringify(response));

                                                    });


                               }, function(error) {
                            //error
                        });




                    },
                    function(error) {
                        console.log('fetchUserDetails error : ' + JSON.stringify(error));
                    });


            };
            $scope.loadDataInvitesToday = function() {
                //console.log('Refreshing!');
                $timeout(function() {
                    //simulate async response
                    $scope.todaysBookingInvites();

                    //Stop the ion-refresher from spinning
                    $scope.$broadcast('scroll.refreshComplete');

                }, 1000);
                 

            };

             $scope.loadDashboardData = function() {
                 
                $timeout(function() {
                    
                    $scope.dashboardData();
                         $scope.$broadcast('scroll.refreshComplete');

                }, 1000);
                 };
            $scope.loadDataInvitestomorrow = function() {
                /*$scope.loadingIndicator = $ionicLoading.show({
                    template: '<ion-spinner icon="spiral"></ion-spinner>'

                });
                $scope.tomorrowsBookingInvites();
                $timeout(function() {

                    $ionicLoading.hide();
                }, 1500);*/
                //console.log('Refreshing!');
                $timeout(function() {
                    //simulate async response
                    $scope.tomorrowsBookingInvites();

                    //Stop the ion-refresher from spinning
                    $scope.$broadcast('scroll.refreshComplete');

                }, 1000);
            }
            $scope.loadDataAssign = function() {
                //console.log('Refreshing!');
                $timeout(function() {
                    //simulate async response
                    $scope.assignduty();

                    //Stop the ion-refresher from spinning
                    $scope.$broadcast('scroll.refreshComplete');

                }, 1000);

                /* $scope.loadingIndicator = $ionicLoading.show({
                     template: '<ion-spinner icon="spiral"></ion-spinner>'

                 });
                 $scope.assignduty();
                 $timeout(function() {

                     $ionicLoading.hide();
                 }, 1500);*/

            };
            $scope.loadDataJob = function() {
                //console.log('Refreshing!');
                $timeout(function() {
                    //simulate async response
                    $scope.getJob();

                    //Stop the ion-refresher from spinning
                    $scope.$broadcast('scroll.refreshComplete');

                }, 1000);



            };
            $scope.loadDatacurrent = function() {
                //console.log('Refreshing!');
                $timeout(function() {
                    //simulate async response
                    $scope.dashboardData();
                    $scope.currentDuty();
                    //Stop the ion-refresher from spinning
                    $scope.$broadcast('scroll.refreshComplete');

                }, 1000);

                /*$scope.loadingIndicator = $ionicLoading.show({
                    template: '<ion-spinner icon="spiral"></ion-spinner>'

                });
                $scope.currentDuty();
                $timeout(function() {

                    $ionicLoading.hide();
                }, 1500);
*/
            };
            $scope.loadDatacurrentBooking = function() {

                $scope.loadingIndicator = $ionicLoading.show({
                    template: '<ion-spinner icon="spiral"></ion-spinner>'

                });
                $scope.allBookings();
                $timeout(function() {

                    $ionicLoading.hide();
                }, 1500);

            };
            $scope.loadDataDuties = function() {

                $scope.loadingIndicator = $ionicLoading.show({
                    template: '<ion-spinner icon="spiral"></ion-spinner>'

                });
                $scope.getAllDuties();
                $timeout(function() {

                    $ionicLoading.hide();
                }, 1500);

            };
            $scope.loadLocalDataDuties = function() {

                //console.log('Refreshing!');
                $timeout(function() {
                    //simulate async response
                    $scope.getLocalDuties();

                    //Stop the ion-refresher from spinning
                    $scope.$broadcast('scroll.refreshComplete');

                }, 1000);
                /*$scope.loadingIndicator = $ionicLoading.show({
                    template: '<ion-spinner icon="spiral"></ion-spinner>'

                });
                $scope.getLocalDuties();
                $timeout(function() {

                    $ionicLoading.hide();
                }, 1500);*/

            };
            $scope.loadratecard = function() {
                //console.log('Refreshing!');
                $timeout(function() {
                    //simulate async response
                    $scope.dashboardData();
                    $scope.rateCardData();

                    //Stop the ion-refresher from spinning
                    $scope.$broadcast('scroll.refreshComplete');

                }, 1000);



            };
            $scope.loadAccountSammary = function() {
                //console.log('Refreshing!');
                $timeout(function() {
                    //simulate async response
                    $scope.loadTransactionDetails();

                    //Stop the ion-refresher from spinning
                    $scope.$broadcast('scroll.refreshComplete');

                }, 1000);

                /*$scope.loadingIndicator = $ionicLoading.show({
                    template: '<ion-spinner icon="spiral"></ion-spinner>'

                });
                $scope.loadTransactionDetails();
                $timeout(function() {

                    $ionicLoading.hide();
                }, 1500);*/

            };
            $scope.loadOutstationDataDuties = function() {
                //console.log('Refreshing!');
                $timeout(function() {
                    //simulate async response
                    $scope.getOutstationDuties();

                    //Stop the ion-refresher from spinning
                    $scope.$broadcast('scroll.refreshComplete');

                }, 1000);
                /*console.log('called');
                $scope.loadingIndicator = $ionicLoading.show({
                    template: '<ion-spinner icon="spiral"></ion-spinner>'

                });
                $scope.getOutstationDuties();
                $timeout(function() {

                    $ionicLoading.hide();
                }, 1500);*/

            };




$scope.goToInvites = function(invite) {
if (invite == 'today') {

    var alertPopup = $ionicPopup.alert({
        title: 'Title',
        template: 'नवीन ड्युटी घेण्या करिता माघील ड्युटी इंडियन ड्राईव्हर्स मध्ये फोन करून पेड करून घ्यावे जर ग्राहका कडून पैसे घेतले असल्यास  ACCEPT CASH असे बटन दाबावे. '
    });

    alertPopup.then(function(res) {
        $state.go('current-duty');
        // Custom functionality....
    });

    $rootScope.hide();
    $state.go('today_duty_invite');


}
if (invite == 'tomorrow')

{
    $rootScope.hide();
    $state.go('tomorrow_duty_invites');
}
};

            $scope.tomorrowsBookingInvites = function() {
                $scope.isDisabled = false;
                $rootScope.show();
                var data = [];
                $scope.dashboardData();

                //console.log('$rootScope.ConUsers:' + JSON.stringify($rootScope.ConUsers));
                Bookings.getDriverInvites({

                        driverId: $rootScope.driverId
                        /*filter:{
                        where: {
                            reporting_date: new Date();
                        }
                        }*/
                    },
                    function(response) {

                        //console.log('success booking invites' + JSON.stringify(response));
                        for (var i = 0; i < response.length; i++) {
                            var gdate = new Date();
                            gdate = gdate.setDate(gdate.getDate() + 1);
                            gdate = $filter('date')(gdate, 'dd/MM/yyyy');
                            var rdate = $filter('date')(response[i].reporting_date, 'dd/MM/yyyy');

                            if (rdate === gdate) {
                                data.push(response[i]);
                                //console.log('invites: ' + JSON.stringify(response[i]));
                            }
                        }
                        //console.log('data: ' + JSON.stringify(data));
                        $rootScope.hide();
                        $rootScope.invites = data;


                    },
                    function(error) {
                      //  console.log('fail' + JSON.stringify(error));


                    });

            };
            $scope.todaysBookingInvites = function() {
                $scope.isDisabled = false;
                $rootScope.show();
                var data = [];
                $scope.dashboardData();

                //console.log('$rootScope.ConUsers:' + JSON.stringify($rootScope.ConUsers));
                Bookings.getDriverInvites({

                        driverId: $rootScope.driverId
                        /*filter:{
                        where: {
                            reporting_date: new Date();
                        }
                        }*/
                    },
                    function(response) {

                       // console.log('success booking invites' + JSON.stringify(response));
                        for (var i = 0; i < response.length; i++) {

                            var gdate = $filter('date')(new Date(), 'dd/MM/yyyy');
                            var rdate = $filter('date')(response[i].reporting_date, 'dd/MM/yyyy');

                            if (rdate === gdate) {
                                data.push(response[i]);
                                //console.log('invites: ' + JSON.stringify(response[i]));
                            }
                        }
                        //console.log('data: ' + JSON.stringify(data));
                        $rootScope.hide();
                        $rootScope.invites = data;


                    },
                    function(error) {
                       // console.log('fail' + JSON.stringify(error));


                    });

            };
            $scope.getDuties = function() {
                Bookings.getDriverInvites({
                        driverId: $rootScope.driverId
                    },
                    function(response) {
                        //console.log('success booking invites' + JSON.stringify(response));
                        $rootScope.duties = response;

                    },
                    function(error) {
                       // console.log('fail' + JSON.stringify(error));


                    });

            };
            $scope.converToTwelveHour = function(time) {
                if (!angular.isUndefined(time)) {
                    var hours = time.split(':')[0];
                    var minutes = time.split(':')[1];
                    var ampm = hours >= 12 ? 'PM' : 'AM';
                    hours = hours % 12;
                    hours = hours ? hours : 12; // the hour '0' should be '12'
                    if (minutes === '00') {
                        minutes = '00';
                    } else {
                        minutes = minutes < 10 ? +minutes : minutes;
                    }
                    var strTime = hours + ':' + minutes + ' ' + ampm;
                }
                return strTime;
            }

            function convertToTwentyFourHours(time) {

                var hours = Number(time.match(/^(\d+)/)[1]);
                var minutes = Number(time.match(/:(\d+)/)[1]);
                var AMPM = time.match(/\s(.*)$/)[1];
                if (AMPM == "PM" && hours < 12) hours = hours + 12;
                if (AMPM == "AM" && hours == 12) hours = hours - 12;
                var sHours = hours.toString();
                var sMinutes = minutes.toString();
                if (hours < 10) sHours = "0" + sHours;
                if (minutes < 10) sMinutes = "0" + sMinutes;
                var c_time = sHours + ":" + sMinutes + ":" + "00";
                return c_time;


            }
            $scope.loadDataAssignDutyToday = function() {

            }


            $scope.assignduty = function() {
                $rootScope.show();
                $scope.dashboardData();
                //console.log("Driver Id: " + $rootScope.driverId);
                //console.log('$rootScope.ConUsers     ' + JSON.stringify($rootScope.ConUsers));

                Bookings.getDriverDuties({
                        driverId: $rootScope.driverId
                    },
                    function(response) {
                         if(response.length === 0){
                           if($rootScope.assigndutystatus === 'Line Up'){
                            Bookings.findOne({
                                filter:{
                                    where:{
                                        status: $rootScope.assigndutystatus,
                                        driverId: $rootScope.driverId
                                    }
                                }
                            },function(suc){
                                console.log('cityName: '+JSON.stringify(suc));
                                $scope.cty = suc.operationCity;
                                              Cities.findOne({
                                                filter:{
                                                    where:{
                                                       cityName:$scope.cty 
                                                    }
                                                }
                                            },function(citydetails){
                                               // console.log('cityName: '+JSON.stringify(city));
                                                $scope.contactNumber = citydetails.contactNumber;
                                 
                                $rootScope.statusMessage = 'Your Booking Id '+suc.id +' is in LINE UP state, kindly contact Indian Drivers '+$scope.contactNumber +' for on, off or cancel the duty';
                                 },function(error){

                            });
                            },function(error){

                            });
                           }
                        }
                        console.log('success booking invites accepted' + JSON.stringify(response));
                        $rootScope.hide();
                        $rootScope.assigns = response;

                    },
                    function(error) {
                     //   console.log('fail' + JSON.stringify(error));
//

                    });

            };
            $scope.getOutstationDuties = function() {
                $rootScope.show();
                $scope.dashboardData();
                //console.log('id: ' + JSON.stringify($rootScope.driverId));
                Bookings.getDriverOutstationSummary({
                        driverId: '' + $rootScope.driverId

                    },
                    function(response) {
                        //console.log('my all duties : ' + JSON.stringify(response));
                        $rootScope.hide();
                        $scope.outstationduties = response;
                    },
                    function(error) {
                        $rootScope.hide();
                        $cordovaDialogs.alert('Service Unavailable!', 'Alert');

                      //  console.log('error fetching in all dutis: ' + JSON.stringify(error));
                    });
            }
            $scope.getLocalDuties = function() {
                $rootScope.show();
                $scope.dashboardData();
                //console.log('id: ' + JSON.stringify($rootScope.driverId));
                Bookings.getDriverLocalSummary({
                        driverId: '' + $rootScope.driverId

                    },
                    function(response) {
                        //console.log('my all duties : ' + JSON.stringify(response));
                        $rootScope.hide();
                        $scope.localduties = response;
                    },
                    function(error) {
                        $rootScope.hide();
                        $cordovaDialogs.alert('Service Unavailable!', 'Alert');

                       // console.log('error fetching in all dutis: ' + JSON.stringify(error));
                    });
            }

            function fetchBookingDetail(bookingId) {
                Bookings.find({
                        filter: {
                            where: {
                                id: bookingId
                            },
                            include: [{
                                relation: 'invoices',
                                scope: {
                                    include: {
                                        relation: 'invoiceDetails'
                                    }
                                }
                            }, {
                                relation: 'localBookings'
                            }, {
                                relation: 'outstationBookings'
                            }]
                        }
                    },
                    function(response) {
                        //console.log('my bookings : ' + JSON.stringify(response));
                        $scope.myBookings = response;
                        /*//fetchInvoiceId();
                        timeInterval = setInterval(function() {
                            fetchInvoiceId();
                        }, 10000)*/


                    },
                    function(error) {
                      //  console.log('error fetching my bookings : ' + JSON.stringify(error));
                    });

            }




       
            /**
             * Sets initial user position.
             */
          
        }
    ]);