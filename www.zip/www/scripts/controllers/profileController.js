/**
 * @ngdoc function
 * @name starter.controller:profileCtrl
 * @description
 * # profileCtrl
 * Profile controller of the app
 */
'use strict';
angular.module('conControllers')
    .controller('profileCtrl', ['$rootScope', '$scope', '$localStorage', '$state', '$filter', '$ionicModal', 'ENV', 'API', 'ConUsers', '$cordovaDialogs', '$ionicSlideBoxDelegate', '$ionicHistory', 'BookingInvites', 'Bookings', 'DriverDetails',
        function($rootScope, $scope, $localStorage, $state, $filter, $ionicModal, ENV, API, ConUsers, $cordovaDialogs, $ionicSlideBoxDelegate, $ionicHistory, BookingInvites, Bookings, DriverDetails) {

            
            $scope.invalidFirstName = null;
            $scope.invalidLastName = null;

            $scope.inValidMobileNo = null;
            $scope.inValidAddress = null;
            $scope.inValidAddress2 = null;
            $scope.inValidAddress3 = null;
            $scope.inValidBatch = null;

            $scope.inValidEmergencyNo = null;

            $scope.inValidAge = null;
            $scope.inValidExperience = null;


            //$scope.addressLine2 = null;

            $scope.dashboard = function() {
                $state.go('dashboard');
            };


            $scope.fetchUserDetails = function() {
                $rootScope.show();
                ConUsers.findById({
                        id: $rootScope.ConUsers.user.id
                    },
                    function(response) {
                        //console.log('fetchUserDetails success : ' + JSON.stringify(response));
                        $scope.user = response;
                        DriverDetails.findOne({
                            filter: {
                                where: {
                                    conuserId: $rootScope.ConUsers.user.id
                                }
                            }

                        }, function(success) {

                            //console.log('success driver details: ' +JSON.stringify(success));
                            $rootScope.hide();
                            $scope.drivers = success;
                            $scope.drivers.age =$scope.getAge(success.BDate);

                            //console.log('date: '+JSON.stringify($rootScope.ConUsers.user.id));  
                            $scope.trDate = $filter('date')($scope.drivers.trDate, 'dd/MM/yyyy');
                            $scope.ntDate = $filter('date')($scope.drivers.ntDate, 'dd/MM/yyyy');
                        }, function(error) {
                            //error
                        });




                    },
                    function(error) {
                       // console.log('fetchUserDetails error : ' + JSON.stringify(error));
                    });
            };

            $scope.updateProfile = function() {
                var isValid = profileValidation($scope.user, $scope.drivers);
                if (isValid) {
                    $scope.user.updatedBy = $rootScope.ConUsers.user.id;
                    $scope.user.updatedDate = new Date();
                    $scope.user.$save();


                    $scope.drivers.updatedDate = new Date();
                    $scope.drivers.updatedBy = $rootScope.ConUsers.user.id;
                    $scope.drivers.$save();

                    $cordovaDialogs.alert('Profile updated successfully.', 'Profile');
                }
            };

            function profileValidation(user, drivers) {
                var isValid = true;
                $scope.invalidFirstName = null;
                $scope.invalidLastName = null;
                $scope.inValidEmergencyNo = null;
                $scope.inValidMobileNo = null;
                $scope.inValidAddress = null;
                $scope.inValidAddress2 = null;
                $scope.inValidAddress3 = null;
                $scope.inValidBatch = null;
                $scope.inValidAge = null;
                $scope.inValidExperience = null;



                if (angular.isUndefined(user) || angular.isUndefined(drivers)) {

                    $scope.invalidFirstName = 'First name is Compulsory';
                    $scope.invalidLastName = 'Last name is Compulsory';
                    $scope.inValidEmergencyNo = 'Emergency number is Compulsory';
                    $scope.inValidMobileNo = 'Mobile No is Compulsory';
                    $scope.inValidAddress = 'Address is Compulsory';
                    $scope.inValidAddress2 = 'Location is Compulsory';
                    $scope.inValidBatch = 'Batch is Compulsory';
                    $scope.inValidAge = 'Age is Compulsory ';
                    $scope.inValidExperience = 'Experience is Compulsory';

                    isValid = false;
                } else {


                    if (angular.isUndefined(user.firstName) || user.firstName == '') {

                        $scope.invalidFirstName = 'First name is Compulsory';
                        isValid = false;
                    }
                    if (angular.isUndefined(user.lastName) || user.lastName == '') {

                        $scope.invalidLastName = 'Last name is Compulsory';
                        isValid = false;
                    }
                    if (angular.isUndefined(drivers.driverBatch) || angular.isUndefined(drivers.driverBatch) || drivers.driverBatch == '' || drivers.driverBatch == '') {

                        $scope.inValidBatch = 'Batch is Compulsory';
                        isValid = false;
                    }


                    if (angular.isUndefined(user.email)) {

                        $scope.inValidEmail = 'Email is Compulsory';
                        isValid = false;
                    } else {
                        var mailTest = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
                        if (!mailTest.test(user.email)) {

                            $scope.inValidEmail = 'Please enter valid Email';
                            isValid = false;
                        }
                    }



                    if (angular.isUndefined(user.mobileNumber) || user.mobileNumber == null) {

                        $scope.inValidMobileNo = 'Mobile number is Compulsory';
                        isValid = false;
                    } else {
                        var mobileNo = user.mobileNumber;
                        if (mobileNo.toString().length != 10) {
                            $scope.inValidMobileNo = 'Mobile number should be 10 digit';
                            isValid = false;
                        }
                    }
                    if (angular.isUndefined(drivers.emergencyNumber) || drivers.emergencyNumber == null) {

                        $scope.inValidEmergencyNo = 'Emergency number is Compulsory';
                        isValid = false;
                    } else {
                        var mobileNo = drivers.emergencyNumber;
                        if (mobileNo.toString().length != 10) {
                            $scope.inValidEmergencyNo = 'Emergency number should be 10 digit';
                            isValid = false;
                        }
                    }

                    if (angular.isUndefined(user.address)) {

                        $scope.inValidAddress2 = 'Location is Compulsory';
                        isValid = false;
                    } else if (user.address == '') {

                        $scope.inValidAddress2 = 'Location can not be blank';
                        isValid = false;
                    }

                    if (angular.isUndefined(drivers.freeAddress)) {

                        $scope.inValidAddress = 'Address is Compulsory';
                        isValid = false;
                    } else if (drivers.freeAddress == '') {

                        $scope.inValidAddress = 'Address cannot be blank';
                        isValid = false;
                    }


                }

                  if (angular.isUndefined(drivers.Age)) {

                        $scope.inValidAge = 'Age is Compulsory';
                        isValid = false;
                    } else if (drivers.freeAge == '') {

                        $scope.inValidAge = 'Age cannot be blank';
                        isValid = false;
                    }
                      if (angular.isUndefined(drivers.Experience)) {

                        $scope.inValidExperience = 'Experience is Compulsory';
                        isValid = false;
                    } else if (drivers.freeExperience == '') {

                        $scope.inValidExperience = 'Experience cannot be blank';
                        isValid = false;
                    }
                return isValid;

            }
                $scope.getAge = function(birthday){
        if(angular.isUndefined(birthday) || birthday === '' || birthday=== null){
            return 0;
        }else{


                   var birthday = new Date(birthday);
                      var today = new Date();
                      var age = ((today - birthday) / (31557600000));
                      var age = Math.floor( age );
                      return age;
             }
  }

            $scope.logout = function() {
                //console.log('local storage: ' + JSON.stringify($localStorage.user));
                $rootScope.driverDetails = undefined;
                $rootScope.transactionDetails = undefined;
                $rootScope.otpNo = undefined;
                $ionicHistory.clearHistory();
                $ionicHistory.clearCache();
                delete $localStorage.user;
                $rootScope.ConUsers = undefined;
                $ionicHistory.nextViewOptions({
                    disableBack: true

                });

                //console.log('local storage: ' + JSON.stringify($localStorage.user));
                $state.go('login');
            };

        }
    ]);