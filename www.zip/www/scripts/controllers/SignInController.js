/**
 * @ngdoc function
 * @name conControllers:SignInCtrl
 * @description
 * # SignInCtrlvar isValid =
 * Sign-in controller of the app
 */
'use strict';
angular.module('conControllers', [])
    .controller('SignInCtrl', ['$rootScope', '$scope', 'ENV', '$ionicViewService', '$state', '$filter', '$http', '$ionicModal', '$ionicSlideBoxDelegate',
        '$ionicHistory', '$cordovaDialogs', '$ionicPopup', 'API', 'ConUsers', 'UserRoles', 'UserDevices', '$localStorage', '$timeout', 'DriverDetails', 'Bookings',  '$ionicLoading', 'Cities',
        function($rootScope, $scope, ENV, $ionicViewService, $state, $filter, $http, $ionicModal, $ionicSlideBoxDelegate, $ionicHistory, $cordovaDialogs, $ionicPopup, 
            API, ConUsers, UserRoles, UserDevices, $localStorage, $timeout, DriverDetails, Bookings, $ionicLoading, Cities) {
            $rootScope.logo = ENV.logo;
            $rootScope.driver = ENV.driver;
            $rootScope.logoApp = ENV.logoApp;
            $scope.focusMe = true;
            $rootScope.appLogo = ENV.appLogo;
            $rootScope.userIcon = ENV.userIcon;
            $scope.errorMsg = null;
            $scope.addressLine2 = null;
            $scope.inValidMobileNo = null;
            $scope.inValidAddress2 = null;
            $scope.mobileNoFlag = true;
            $scope.invalidFirstName = null;
            $scope.invalidLastName = null;
            $scope.inValidMobileNo = null;
            $scope.inValidAddress = null;
            $scope.invalidCity =null;
            $scope.insertFlag = true;
            $scope.regex = '\\d+';

            /*$scope.address = null;*/
            $scope.addressLat = null;
            $scope.addressLon = null;
            $rootScope.smsFlag = true;

            $scope.back = function(){
                if (angular.isDefined($localStorage.user)) {
                    $state.go('profile');
                
            }else{
                $state.go('login');
            }
        }


            $ionicModal.fromTemplateUrl('templates/otp-authentication-fail-modal.html', function($ionicOTPFailModal) {
                $scope.otpFail = $ionicOTPFailModal;
            }, {
                // Use our scope for the scope of the modal to keep it simple
                scope: $scope,
                // The animation we want to use for the modal entrance
                animation: 'slide-in-left',
                backdropClickToClose: false,
                hardwareBackButtonClose: true
            }).then(function(otpFail) {
                $scope.otpFail = otpFail;
                //console.log('In $ionicModal Search Modal');
            });

            $scope.$on('$cordovaPush:notificationReceived', function(event, notification) {
                //console.log(JSON.stringify([notification]));

                if (ionic.Platform.isAndroid()) {
                    handleAndroid(notification);

                } else if (ionic.Platform.isIOS()) {
                    // handleIOS(notification);

                }
            });


            /*$scope.login = function(mobileno) {
                $state.go('verify');

            };*/



            $scope.acceptCash = function() {
                $state.go('accept-cash');
            };

            $scope.dashboard = function() {
                $state.go('dashboard');
            };

            $scope.showProfile = function() {
                $state.go('profile');
            };

            $scope.logout = function() {
                //console.log('local storage: ' + JSON.stringify($localStorage.user));
                $rootScope.driverDetails = undefined;
                $rootScope.transactionDetails = undefined;
                rootScope.otpNo = null;
                $localStorage.user.clear();
                $ionicHistory.clearHistory();
                $ionicHistory.clearCache();
                delete $localStorage.user;
                $ionicHistory.nextViewOptions({
                    disableBack: true

                });
                //$localStorage.user = null;
                //console.log('local storage: ' + JSON.stringify($localStorage.user));
                $state.go('login');
            };
            $scope.selectTabWithIndex = function(index) {
                $ionicTabsDelegate.select(index);
            };

            $scope.isExistMobile = function(mobileno) {
                $rootScope.mobileno = mobileno;
                $rootScope.show();
                $rootScope.user = undefined;
                $localStorage.user = undefined;
                $localStorage.canAutologin = undefined;


                var isValid = checkValidmobileNo($rootScope.mobileno);

                if (isValid) {
                    ConUsers.validateDriverMobile({
                        mobileNumber: mobileno
                    }, function(checkuser) {
                        //console.log('checkuser ' +JSON.stringify(checkuser));
                        if (checkuser[0].validate_driver_mobile === '0') {
                            $scope.signIn(mobileno);
                        } else if (checkuser[0].validate_driver_mobile === '1') {

                            verifyMobileNo($rootScope.mobileno);
                            $rootScope.hide();
                        } else if (checkuser[0].validate_driver_mobile === '2') {
                            $rootScope.hide();
                            $rootScope.inActive = true;
                            $scope.signIn(mobileno);
                            //$cordovaDialogs.alert('Your registration is in progress. For more details please contact 020-69400400', 'Alert');
                        } else if (checkuser[0].validate_driver_mobile === '3') {
                            $scope.inValidMobileNo = 'You cannot login by this number.';
                            $rootScope.hide();

                        } else {


                        }
                    }, function(usererror) {
                        $rootScope.hide();

                        $cordovaDialogs.alert('Service Unavailable. Please try later.', 'Alert');


                    });


                }

            };

            $scope.signIn = function(mobileno) {

                $rootScope.show();
                $scope.loginResult = ConUsers.login({
                        username: '' + mobileno + '',
                        password: '' + mobileno + ''
                    },
                    function(value) {
                        // success
                        //console.log('Success' + JSON.stringify(value));
                        // delete $localStorage.user;
                        $rootScope.ConUsers = value;
                     $rootScope.operationCity = value.user.operationCity;
                        //console.log('$rootScope.ConUsers' + JSON.stringify($rootScope.ConUsers.userId));
                        //console.log('$rootScope.ConUsers.status:' + JSON.stringify($rootScope.ConUsers.user.status));

                        verifyMobileNo(mobileno);
                        $rootScope.hide();


                    },
                    function(res) {
                        if (res.status === 401) {
                            $scope.inValidMobileNo = 'Please enter valid credential.';
                        } else if (res.status === 400) {
                            $scope.inValidMobileNo = 'Please enter valid mobile no.';
                        } else {
                            $scope.inValidMobileNo = 'Sorry you are not connected to the Internet, please try again later. ';
                        }
                    });




            };
            $ionicModal.fromTemplateUrl('templates/search-modal.html', function($ionicSearchModal) {
                $scope.searchModal = $ionicSearchModal;
            }, {
                // Use our scope for the scope of the modal to keep it simple
                scope: $scope,
                // The animation we want to use for the modal entrance
                animation: 'slide-in-left',
                backdropClickToClose: false,
                hardwareBackButtonClose: true,
                focusFirstInput: true
            }).then(function(searchModal) {
                $scope.searchModal = searchModal;
                //console.log('In $ionicModal Search Modal');
            });

            $scope.closeSearchModal = function() {

                //console.log('I am in close search Modal');
                if (!angular.isUndefined($rootScope.map) && $rootScope.map !== null) {
                    $rootScope.map.setClickable(true);
                }
                $scope.searchModal.hide();
            };

             
            $scope.signUp = function() {
                //console.log('signeup');
                //$cordovaDialogs.alert('Sign Up Controller Call');
                //$state.go($state.current, {}, {reload: true});
                $state.go('signUp');
            };
            $scope.operationCity = function() {
                  Cities.find({
                           
                   },function(citysuccess){
                       
                      $rootScope.cityAt = [];
        for(var i = 0; i<citysuccess.length; i++){
            
            if(citysuccess[i].cityName !== 'All'){
                $rootScope.cityAt.push(citysuccess[i].cityName);
            }
        }


                   },function(cityerr){ 
                 
                   });
              }

            $scope.signUpDriver = function(user) {
                $rootScope.show();

                signUpValidation(user);
                if ($scope.insertFlag) {
                    ConUsers.createDriverForDriverAppNew({
                        mobileNumber: user.mNumber,
                        email: user.mNumber + '@consrv.in',
                        firstName: user.firstName,
                        middleName: user.middleName,
                        lastName: user.lastName,
                        username: user.mNumber,
                        password: '' + user.mNumber,
                        isLuxury: 'Manual',
                        freeAddress: user.address,
                        operationCity:user.city,
                        addressLat: 0,
                        addressLong: 0,
                        googleAddress: user.addressLine2,
                        otp: ''+$rootScope.otp 
                        
                    }, function(driverregistrationsuccess) {
                        //console.log('driver registartion : ' +JSON.stringify(driverregistrationsuccess));
                        if (driverregistrationsuccess[0].create_driver === '0') {
                            $cordovaDialogs.alert('Your are successfully registered', 'Alert');
                            sendsmsToDriver(user);
                            $scope.loginResult = ConUsers.login({
                        username: '' + user.mNumber + '',
                        password: '' + user.mNumber + ''
                    },
                    function(value) { 
                        $rootScope.ConUsers = value;
                        $rootScope.operationCity = value.user.operationCity; 
                        $localStorage.user = {
                                    'mobileno': user.mNumber,
                                    'password': user.mNumber
                                };

                                getDriverDetail();
                                fetchCurrentDuty();
                                $ionicViewService.nextViewOptions({
                                    disableBack: true
                                });
                                $ionicViewService.clearHistory();
                                $ionicHistory.clearHistory();
                                $state.go('dashboard');
                          },
                    function(res) {
                        if (res.status === 401) {
                            $scope.inValidMobileNo = 'Please enter valid credential.';
                        } else if (res.status === 400) {
                            $scope.inValidMobileNo = 'Please enter valid mobile no.';
                        } else {
                            $scope.inValidMobileNo = 'Sorry you are not connected to the Internet, please try again later. ';
                        }
                    });
                            $rootScope.hide();

                        } else if (driverregistrationsuccess[0].create_driver === '1') {
                            $rootScope.hide();
                            $cordovaDialogs.alert('Mobile Number Already Exist. Please Login.', 'Alert');
                            $state.go('login');


                        }

                        // $rootScope.hide();
                    }, function(driverregistrationerr) {
                        $rootScope.hide();
                        if (driverregistrationerr.status === 503) {
                            $cordovaDialogs.alert('Service Unavailable. Please try again later.', 'Alert');
                        } else {
                            $cordovaDialogs.alert('Sorry you are not connected to the Internet, Unable to register. please try again later.');
                        }
                        console.log('driver registartion : ' + JSON.stringify(driverregistrationerr));
                    });

                }
            };
//getcity
/*$scope.cityAt = [
     {name:'Aurangabad'},
     {name:'Pune'}
     
   ]; */ 
              /*$scope.operationCity = function() {
                 Cities.find({
                         
                  },function(citysuccess){
                      $rootScope.cities=[];
                      for(var i=0; i< citysuccess.length; i++){
                          $rootScope.cities.push(
                             citysuccess.cityName);
                      }


                  },function(cityerr){}
               
                  )};*/

            function sendsmsToDriver(user) {
                var msg = 'Dear ' + user.firstName + ', Thank you for registering with Indian Drivers.';
                if ($rootScope.smsFlag === true) {
                    ConUsers.sendSMS({
                        mobileNumber: user.mNumber,
                        msg: msg
                    }, function(mgssuccess) {
                        //console.log('msg sent successfully:' +JSON.stringify(mgssuccess));
                        $rootScope.smsFlag = false;
                    }, function(error) {
                        $rootScope.hide();
                        //console.log('error in sending msg: ' + JSON.stringify(error));
                        $rootScope.smsFlag = false;

                    });
                }
            };

            function signUpValidation(user) {

                $scope.invalidFirstName = null;
                $scope.invalidLastName = null;
                $scope.inValidMobileNo = null;
                $scope.inValidAddress = null;
                $scope.inValidAddress2 = null;
                $scope.invalidCity = null;
                $scope.addressLine2ForValidation = user.addressLine2;
                //$scope.inValidBatch = null;
                // $scope.address = null;
                $scope.insertFlag = true;

                if (angular.isUndefined(user)) {
                    $scope.insertFlag = false;
                    $scope.invalidFirstName = 'First name is Compulsory';
                    $scope.invalidLastName = 'Last name is Compulsory';
                    $scope.inValidMobileNo = 'Mobile No is Compulsory';
                    $scope.inValidAddress = 'Address is Compulsory';
                    $scope.inValidAddress2 = 'Google Address is Compulsory';
                    $scope.invalidCity = 'City is Compulsory'
                    $rootScope.hide();
                    //$scope.inValidBatch = 'Batch is compulsory';
                } else {
                    //for Name validation
                    if (angular.isUndefined(user.firstName) || user.firstName === '') {
                        $scope.insertFlag = false;
                        $scope.invalidFirstName = 'First name is Compulsory';
                        $rootScope.hide();
                    }
                    if (angular.isUndefined(user.lastName) || user.lastName === '') {

                        $scope.insertFlag = false;
                        $scope.invalidLastName = ' Last name is Compulsory';
                        $rootScope.hide();
                    }

                    if (angular.isUndefined(user.mNumber) || user.mNumber === null) {
                        $scope.insertFlag = false;
                        $scope.inValidMobileNo = 'Mobile Number is Compulsory';
                        $rootScope.hide();
                    } else {
                        var mobileNo = user.mNumber;
                        if (mobileNo.toString().length !== 10) {
                            $scope.insertFlag = false;
                            $scope.inValidMobileNo = 'Mobile Number should be 10 digit';
                            $rootScope.hide();
                        }
                    }
                    //address valdation
                    if (angular.isUndefined(user.address) || user.address === null) {
                        $scope.insertFlag = false;
                        $scope.inValidAddress = 'Address is Compulsory';
                        $rootScope.hide();
                    } else if (user.address == '') {
                        $scope.insertFlag = false;
                        $scope.inValidAddress = 'Address can not be blank';
                        $rootScope.hide();
                    } else {
                        //do nothing
                    }
                    if (angular.isUndefined($scope.addressLine2ForValidation)) {
                        $scope.insertFlag = false;
                        $scope.inValidAddress2 = 'Enter Google Address.';
                        $rootScope.hide();
                    }  
                    else if ($scope.addressLine2ForValidation == '' || $scope.addressLine2ForValidation == null) {
                        $scope.insertFlag = false;
                        $scope.inValidAddress2 = 'Google Address field can not be blank.';
                        $rootScope.hide();
                    } else {
                         
                    }
                    if (angular.isUndefined(user.city) || user.city === '' || user.city === null) {
                        $scope.insertFlag = false;
                        $scope.invalidCity = 'City is Compulsory';
                        $rootScope.hide();
                    }



                }
            };

            $scope.onloade = function() {
    setTimeout(function() {
        document.getElementById('yourButton').disabled = false;
    }, 60000);
}

 


            function verifyMobileNo(mobileno) {


                if (!$scope.mobileNoFlag && mobileno != '') {
                    $ionicViewService.nextViewOptions({
                        disableBack: true
                    });
                    $ionicViewService.clearHistory();
                    $ionicHistory.clearHistory();
                    $state.go('verifyOTPNo');
                    return;
                } else {
                    if (mobileno === '') {
                        mobileno = $rootScope.mobileno;
                        //console.log('Resend No' + mobileno);

                    }
                    $rootScope.mobileno = mobileno;

                    var OTP = Math.floor(Math.random() * 90000) + 10000;
                    if (angular.isDefined($rootScope.ConUsers)) {
                        //console.log('Mobile No in rootScope' + $rootScope.mobileno);
                        //console.log('Verify Mobile No : ' + $rootScope.ConUsers.user.id);
                        //console.log('Mobile No : ' + mobileno);
                        ConUsers.findById({
                                id: $rootScope.ConUsers.user.id
                            },
                            function(response) {
                                console.log('fetchUserDetails success : ' + JSON.stringify(response));
                                $scope.user = response;
                               /* if(angular.isDefined($scope.user.otp)){

                                }else{*/
                                    $scope.user.otp = OTP;
                                     $scope.user.$save();
                                     var success = sendSms(mobileno, OTP);
                                /*}*/
                                //
                                //call sens sms function

                                //console.log('saved success : ' + JSON.stringify($scope.user));
                          
                           //
                                //$cordovaDialogs.alert('OTP is successfully sent to you.', 'Login');
                                $ionicViewService.nextViewOptions({
                                    disableBack: true
                                });
                                $ionicViewService.clearHistory();
                                $ionicHistory.clearHistory();
                                $state.go('verifyOTPNo');

                            },
                            function(error) {
                               // console.log('fetchUserDetails error : ' + JSON.stringify(error));
                            });

                    } else {
                        //console.log(mobileno);
                        var success = sendSms(mobileno, OTP);
                        $rootScope.otp = OTP;
                        //$cordovaDialogs.alert('OTP is successfully sent to you.', 'Login');
                        $ionicViewService.nextViewOptions({
                            disableBack: true
                        });
                        $ionicViewService.clearHistory();
                        $ionicHistory.clearHistory();
                        $state.go('verifyOTPNo');


                    }

                }
            }





            $scope.verifyOTPNo = function(otpNo) {
                //console.log('OTP No : ' + otpNo);
                /*console.log(response.otp);*/
                if (angular.isDefined($rootScope.ConUsers)) {
                    ConUsers.findById({
                            id: $rootScope.ConUsers.user.id
                        },
                        function(response) {
                            //console.log('fetchUserDetails success : ' + JSON.stringify(response));

                            console.log('Entered OTP No' + otpNo);
                            console.log('Existing OTP No' + response.otp);


                            if (Number(response.otp) === Number(otpNo)) {

                                 /*SMS.stopWatch(function(){
                //update('watching', 'watching stopped');
            }, function(){
               // updateStatus('failed to stop watching');
            });
                     */                         $localStorage.user = {
                                    'mobileno': $rootScope.mobileno,
                                    'password': $rootScope.mobileno
                                };
                                getDriverDetail();
                                fetchCurrentDuty();
                                $ionicViewService.nextViewOptions({
                                    disableBack: true
                                });
                                $ionicViewService.clearHistory();
                                $ionicHistory.clearHistory();
                                $state.go('dashboard');
                            } else {

                                $scope.otpFail.show();
                            }
                        },
                        function(error) {
                           // console.log('fetchUserDetails error : ' + JSON.stringify(error));
                        });
                } else {
                    console.log('Entered OTP No' + otpNo);
                    console.log('Existing OTP No' + $rootScope.otp);
                    if (Number($rootScope.otp) === Number(otpNo)) {

                                 /*SMS.stopWatch(function(){
                //update('watching', 'watching stopped');
            }, function(){
               // updateStatus('failed to stop watching');
            });*/
                         
                        $rootScope.user = {
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            mNumber: $rootScope.mobileno
                        };
                        $timeout(function() {

                            $ionicLoading.hide();
                        }, 1500);
                        $state.go('signUp');
                    } else {
                        $scope.otpFail.show();
                    }

                }
            };


            $scope.closeOTPFailModal = function() {
                $scope.otpFail.hide();
            }


            function checkValidmobileNo(mobileno) {
                var isValid = true;
                $scope.inValidMobileNo = null;
                var mob = /^[0-9]{1,10}$/;
                $scope.mobileNoFlag = true;
                if (angular.isUndefined(mobileno) || mobileno === null) {
                    $scope.mobileNoFlag = false;
                    isValid = false;
                    $scope.inValidMobileNo = 'Mobile Number is compulsory';
                    $rootScope.hide();
                } else if (angular.isDefined(mobileno)) {
                    if (mobileno.toString().length != 10) {
                        $scope.mobileNoFlag = false;
                        isValid = false;
                        $scope.inValidMobileNo = 'Mobile Number should be 10 digit';
                        $rootScope.hide();
                    }

                } else if (angular.isDefined(mobileno)) {
                    if (mob.test(mobileno.toString()) == false) {
                        $scope.mobileNoFlag = false;
                        isValid = false;
                        $scope.inValidMobileNo = 'Please enter valid mobile number.';
                        $rootScope.hide();
                    }

                } else {
                    //do nothing
                }
                return isValid;

            }


            $scope.resendMsg = function() {

                if (angular.isDefined($rootScope.ConUsers)) {
                    ConUsers.findById({
                            id: $rootScope.ConUsers.user.id
                        },
                        function(response) {
                            //console.log('fetchUserDetails success : ' + JSON.stringify(response));

                            //call sens sms function
                            $scope.user = response;
                                /*if(angular.isDefined($scope.user.otp)){
                                    $cordovaDialogs.alert('OTP is already Resend to you. if problem persist pls contact Indian Drivers on 020 67641000.', 'Alert');
                                
                                }else{*/
                                    $scope.user.otp = OTP;
                                     $scope.user.$save();
                                     $rootScope.smsFlag === true;
                                     var success = sendSms($rootScope.mobileno, response.otp);
                                 $rootScope.smsFlag === false;
                            $state.go('verifyOTPNo');

                               /* }*/
                            //console.log('saved success : ' + JSON.stringify($scope.user));
                             
                            // $cordovaDialogs.alert('OTP is successfully Resend to you.', 'Alert');
                           
                        },
                        function(error) {
                            console.log('fetchUserDetails error : ' + JSON.stringify(error));
                        });
                } else {
                    $rootScope.smsFlag = true;
                    var success = sendSms($rootScope.mobileno, $rootScope.otp);
                    //console.log($rootScope.mobileno + $rootScope.otp);

                    $state.go('verifyOTPNo');
                }

            };


            function sendSms(mobileno, token) {
                var msg = 'Your verification code is-' + token;

                ConUsers.sendSMS({
                    mobileNumber: mobileno,
                    msg: msg
                }, function(mgssuccess) {
                   /*cordova.plugins.AndroidSmsRetriever
        .onSmsReceived(
            
            function successCallback(message) {

                if(message === 'SMS_RETRIEVER_SETUP') {
                    // Here you request server to send the SMS
                    return;
                }

                alert(message);
            },

            function errorCallback(e) {
                console.error(e);
            },

            true //notifyWhenStarted
        );*/
                    /*SMS.startWatch(function(){
       //console.log('Watching');
     }, function(){
      // console.log('Not Watching');
     });*/
                                    /*$scope.loadingIndicator = $ionicLoading.show({
                        template: '<ion-spinner icon="spiral"></ion-spinner>'

                    });*/
                    /*document.addEventListener('onSMSArrive', function(e) {
                        var data = e.data;
                        if (angular.isDefined(data)) {
                            $ionicLoading.hide();
                            //console.log('data: ' +JSON.stringify(data));  
                            var thestring = data.body;
                            var otpnumber = thestring.replace(/^\D+/g, '');
                            //console.log(thestring.replace( /^\D+/g, ''));  
                            if (Number(otpnumber) === token) {
                                $rootScope.otpNo = token;
                                if (angular.isDefined($rootScope.otpNo)) {
                                    $scope.verifyOTPNo($rootScope.otpNo);
                                }
                            }

                        }
                    });*/
                    /*$timeout(function() {

                        $ionicLoading.hide();
                    }, 36000);*/
                    //console.log('msg sent successfully:' +JSON.stringify(mgssuccess));
                    $rootScope.smsFlag = false;
                }, function(error) {
                   // console.log('error in sending msg: ' + JSON.stringify(error));
                    $rootScope.smsFlag = false;

                });


            }




            $scope.autoLogin = function() {
                //console.log('Auto login called');
                //console.log($localStorage.user);
                $rootScope.show();

                if (angular.isUndefined($localStorage.user)) {
                    $rootScope.hide();
                    $timeout(redirectLogin, 3000);
                } else {

                    ConUsers.validateDriverMobile({
                        mobileNumber: $localStorage.user.mobileno
                    }, function(checkuser) {
                        //console.log('checkuser ' +JSON.stringify(checkuser));
                        if (checkuser[0].validate_driver_mobile === '0') {

                            ConUsers.login({
                                    username: '' + $localStorage.user.mobileno + '',
                                    password: '' + $localStorage.user.password + ''

                                },
                                function(value) {
                                    // success
                                    $rootScope.ConUsers = value;
                                    $rootScope.operationCity = value.user.operationCity;
                                    //console.log('Success autologin' + JSON.stringify(value));
                                    $rootScope.hide();
                                    getDriverDetail();
                                    fetchCurrentDuty();
                                    $ionicViewService.nextViewOptions({
                                        disableBack: true
                                    });
                                    $ionicViewService.clearHistory();
                                    $ionicHistory.clearHistory();
                                    $state.go('dashboard');
                                },
                                function(res) {
                                 //   console.log('err :' + JSON.stringify(res));
                                    $rootScope.hide();


                                    $cordovaDialogs.alert('Sorry you are not connected to the Internet, please try again later.', 'Login');
                                    // $cordovaToast.show('Service is not available. Please try again later.', 'long', 'bottom');
                                    // $state.go('login');

                                    //console.log('Login Error: ' + JSON.stringify([res]));
                                });
                        } else if (checkuser[0].validate_driver_mobile === '1') {
                            $state.go('login');
                            //verifyMobileNo($rootScope.mobileno);
                            $rootScope.hide();
                        } else if (checkuser[0].validate_driver_mobile === '2') {
                            $rootScope.hide();
                            $rootScope.inActive = true;
                            ConUsers.login({
                                    username: '' + $localStorage.user.mobileno + '',
                                    password: '' + $localStorage.user.password + ''

                                },
                                function(value) {
                                    // success
                                    $rootScope.ConUsers = value;
                                    $rootScope.operationCity = value.user.operationCity;

                                    //console.log('Success autologin' + JSON.stringify(value));
                                    $rootScope.hide();
                                    getDriverDetail();
                                    fetchCurrentDuty();
                                    $ionicViewService.nextViewOptions({
                                        disableBack: true
                                    });
                                    $ionicViewService.clearHistory();
                                    $ionicHistory.clearHistory();
                                    $state.go('dashboard');
                                },
                                function(res) {
                                   // console.log('err :' + JSON.stringify(res));
                                    $rootScope.hide();


                                    $cordovaDialogs.alert('Sorry you are not connected to the Internet, please try again later.', 'Login');
                                    // $cordovaToast.show('Service is not available. Please try again later.', 'long', 'bottom');
                                    // $state.go('login');

                                    //console.log('Login Error: ' + JSON.stringify([res]));
                                });
                            //$cordovaDialogs.alert('Your registration is in progress. For more details please contact 020-69400400', 'Alert');
                        } else if (checkuser[0].validate_driver_mobile === '3') {
                            $state.go('login');
                            $rootScope.hide();

                        } else {


                        }
                    }, function(usererror) {
                       // console.log('err :' + JSON.stringify(usererror));
                        $rootScope.hide();

                        $cordovaDialogs.alert('Service Unavailable. Please try later.', 'Alert');
                        $ionicViewService.nextViewOptions({
                            disableBack: true
                        });
                        $ionicViewService.clearHistory();
                        $ionicHistory.clearHistory();
                        $state.go('login');

                    });
                    //console.log('Login result: ' + JSON.stringify($scope.loginResult));
                }
            };


            function redirectLogin() {
                //console.log('Redirect login called');

                $ionicHistory.clearHistory();
                $ionicHistory.clearCache();
                $ionicHistory.nextViewOptions({
                    disableBack: true
                });
                $rootScope.hide();
                $state.go('login');
            }


            // Push Notification
            function storeDeviceToken(type) {
                ConUsers.find({
                    filter: {
                        where: {
                            id: $rootScope.ConUsers.user.id
                        },
                        include: {
                            relation: 'userDevices'
                        }
                    }
                }, function(value1) {
                    //console.log('value 1 = ' + JSON.stringify(value1));
                    $scope.deviceId = value1[0].userDevices[0];
                    //console.log('$scope.deviceId' + JSON.stringify($scope.deviceId));
                    if (angular.isUndefined($scope.deviceId)) {
                        //create user device to push notification details
                        UserDevices.create({
                                ConUsersId: $rootScope.ConUsers.user.id,
                                deviceId: $scope.regId,
                                deviceName: type,
                                createdBy: $rootScope.ConUsers.user.id
                            })
                            .$promise
                            .then(function(devices) {
                                    //console.log('UserDevices: after ' + JSON.stringify(devices));
                                    //console.log('User Device Created And Token stored, device is successfully subscribed to receive push notifications.');
                                },
                                function(error) {
                                    $rootScope.hide();
                                    console.log('Error storing device token:' + JSON.stringify(error));
                                });

                    } else {
                        //add/update id provided by push notification service
                        UserDevices.upsert({
                                id: $scope.deviceId.id,
                                deviceId: $scope.regId,
                                deviceName: type,
                                updatedBy: $rootScope.ConUsers.user.id,
                                updatedDate: new Date()
                            },
                            function(UserDevices) {
                                //console.log('Token stored, device is successfully subscribed to receive push notifications.');
                            },
                            function(errorResponse) {
                              //  console.log('Error storing device token:' + errorResponse);
                            });
                    }

                });


            }

            $scope.register = function() {

                var config = null;
                $rootScope.registerDisabled = false;
                if (ionic.Platform.isAndroid()) {
                    config = {
                        'senderID': '182696113585' // REPLACE THIS WITH YOURS FROM GCM CONSOLE - also in the project URL like: https://console.developers.google.com/project/434205989073
                    };
                }
                //console.log('config' + JSON.stringify(config));
                $cordovaPush.register(config).then(function(result) {
                    //console.log('Register success ' + result);
                    //$cordovaDialogs.alert(result, 'result');
                }, function(err) {
                   // console.log('Register error ' + err);
                });


            };

            function handleAndroid(notification) {
                // ** NOTE: ** You could add code for when app is in foreground or not, or coming from coldstart here too
                //             via the console fields as shown.
                //console.log('In foreground ' + notification.foreground + ' Coldstart ' + notification.coldstart);
                //console.log('in handle android');
                if (notification.event === 'registered') {
                    $scope.regId = notification.regid;
                    //console.log(' $scope.regId: ' + JSON.stringify($scope.regId));
                    if ($rootScope.registerDisabled === false) {
                        $rootScope.registerDisabled = true;
                        storeDeviceToken('android');
                    }
                } else if (notification.event === 'message') {
                    //$cordovaDialogs.alert(notification.message, 'DII Notification');
                    /*//$cordovaToast.showShortCenter(notification.message).then(function(success) {
                        console.log('incordova toast'+JSON.stringify(success));
                    }, function(error) {
                        console.log('incordova toast'+JSON.stringify(error));

                    });*/
                } else if (notification.event === 'error') {
                    $cordovaDialogs.alert(notification.msg, 'Push notification error event');
                } else {
                    $cordovaDialogs.alert(notification.event, 'Push notification handler - Unprocessed Event');
                }

                /*if (notification.coldstart === true && (!angular.isUndefined(notification.payload.bookingId))) {
                    console.log('in coldstart and bookingId = ' + bookingId);
                    if (notification.payload.bookingId.length !== 0) {
                        var bookingId = notification.payload.bookingId;
                        $ionicHistory.clearCache();

                        $state.go('app.booking-detail', {
                            bookingId: bookingId
                        });


                    }
                }*/


            }

            function getDriverDetail() {


                DriverDetails.find({
                        filter: {
                            where: {
                                conuserId: $rootScope.ConUsers.user.id
                            }
                        }
                    },
                    function(success) {
                        //console.log("success details" + JSON.stringify(success));
                        $rootScope.driverId = success[0].id;
                        
                        //$rootScope.accountId = success[0].driverAccount[0].id;
                        $state.go('dashboard');
                    },
                    function(error) {
                       // console.log("error" + JSON.stringify(error));
                    });
            }

            function fetchCurrentDuty() {

                Bookings.find({
                        filter: {
                            where: {
                                driverId: $rootScope.driverId,
                                startOffDuty: true,
                                status: 'On Duty'

                            }
                        }
                    },
                    function(response) {
                        //console.log('Booking Detail ' + JSON.stringify(response));
                        //console.log('response[0]= '+ JSON.stringify(response[0]));

                        if (response[0] != null) {
                            $rootScope.currentBooking = response[0].id;
                        }
                        //alert($rootScope.currentBooking);


                    },
                    function(error) {
                     //   console.log('Error In Fetch Current Duty...' + JSON.stringify(error));
                        $cordovaDialogs.alert('Error in fetching Driver Detail', 'My Booking');
                    });
            }

        }
    ])
    .directive('googleplace', function() {
        return {
            require: 'ngModel',
            link: function(scope, element, attrs, model) {
                var options = {
                    types: [],
                    componentRestrictions: {}
                };

                scope.gPlace = new google.maps.places.Autocomplete(element[0], options);

                google.maps.event.addListener(scope.gPlace, 'place_changed', function() {
                    scope.$apply(function() {
                        model.$setViewValue(element.val());
                    });
                });
            }
        };
    })
    .directive('focusMe', function($timeout) {
        return {
            link: function(scope, element, attrs) {
               // console.log("focusMe directive init");
                if (scope.focusMe) {
                    $timeout(function() {
                      //  console.log(" adding focus to element")

                        element[0].focus();
                    }, 150);
                }
            }
        };
    })
    .directive('numbersOnly', function() {
        return {
            require: 'ngModel',
            link: function(scope, element, attrs, modelCtrl) {
                modelCtrl.$parsers.push(function(inputValue) {
                    // this next if is necessary for when using ng-required on your input. 
                    // In such cases, when a letter is typed first, this parser will be called
                    // again, and the 2nd time, the value will be undefined
                    if (inputValue == undefined) return ''
                    var transformedInput = inputValue.replace(/[^0-9]/g, '');
                    if (transformedInput != inputValue) {
                        modelCtrl.$setViewValue(transformedInput);
                        modelCtrl.$render();
                    }

                    return transformedInput;
                });
            }
        };
    })
    .directive('numberOnlyInput', function() {
        return {
            restrict: 'EA',
            template: '<input name="{{inputName}}" ng-model="inputValue" />',
            scope: {
                inputValue: '=',
                inputName: '='
            },
            link: function(scope) {
                scope.$watch('inputValue', function(newValue, oldValue) {
                    var arr = String(newValue).split("");
                    if (arr.length === 0) return;
                    //if (arr.length === 1 && (arr[0] == '-' || arr[0] === '.' )) return;
                    if (arr.length === 2 && newValue === '-.') return;
                    if (isNaN(newValue)) {
                        scope.inputValue = oldValue;
                    }
                });
            }
        };
    })
    .directive('allowPattern', [allowPatternDirective]);

function allowPatternDirective() {
    return {
        restrict: "A",
        compile: function(tElement, tAttrs) {
            return function(scope, element, attrs) {
                // I handle key events
                element.bind("keypress", function(event) {
                    var keyCode = event.which || event.keyCode; // I safely get the keyCode pressed from the event.
                    var keyCodeChar = String.fromCharCode(keyCode); // I determine the char from the keyCode.

                    // If the keyCode char does not match the allowed Regex Pattern, then don't allow the input into the field.
                    if (!keyCodeChar.match(new RegExp(attrs.allowPattern, "i"))) {
                        event.preventDefault();
                        return false;
                    }

                });
            };
        }
    };
};