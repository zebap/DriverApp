// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
angular.module('condriver', ['ionic', 'conControllers', 'conServices', 'config', 'ngStorage', 'ngCordova', 'lbServices'])
    .run(function($ionicPlatform,$http,$ionicPopup) {
        $ionicPlatform.ready(function() {

            
            var permissions = cordova.plugins.permissions;
             var list = [
    permissions.ACCESS_NETWORK_STATE,
    permissions.INTERNET,
    permissions.ACCESS_WIFI_STATE      
     
];
   permissions.hasPermission(list, function( status ){
  if ( !status.hasPermission ) {
    console.log("Yes :D ");
    permissions.requestPermissions(
      list,
      function(status) {
        if( !status.hasPermission ) error();
      },
      error);
  }
  else {
    console.warn("No :( ");
  }
});
 
 var url = 'http://54.202.79.111:3000';
                        $http.post(url + '/getDriverAppLiveVersion').
                                                    success(function(result) {
                                console.log('result:' + JSON.stringify(result));
var plVersion = result;
                        
                        console.log(plVersion);
                 
                cordova.getAppVersion.getVersionNumber().then(function (version) {
                      console.log('version : ' + JSON.stringify(version));
            var version = version.replace(/\./g, "");
            console.log(version);
          if(Number(version)<Number(plVersion)){
            
             var alertPopup = $ionicPopup.alert({
     title: 'Update Info',
     template: 'New version is available. Please update application to proceed.'
   });

   alertPopup.then(function(res) {
       cordova.plugins.market.open('com.mti.driver');
   });
             
        
         
          }
           
        });

                 }).
                                                    error(function(error) {
                                                        // $cordovaDialogs.alert('Error......');
                                                      //  console.log('Error in updating driver invoiceDetails:' + JSON.stringify(error));
                                                    });


            if (ionic.Platform.isIOS() || ionic.Platform.isAndroid()) {
             if(window.cordova) {
             /*    cordova.plugins.AndroidSmsRetriever
        .getAppHash(
            
            function successCallback(hash) {
                alert(hash);
            },

            function errorCallback(e) {
                console.error(e);
            }

        );
              
function error() {
  console.log('Camera or Accounts permission is not turned on');
}*/
                        
        //$cordovaAppVersion.getVersionNumber().then(function (version) {
             
      }
  }
            // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
            // for form inputs)
            if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
                cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
                cordova.plugins.Keyboard.disableScroll(true);

            }
            if (window.StatusBar) {
                // org.apache.cordova.statusbar required
                StatusBar.styleDefault();
            }
        });
    })

.config(function($stateProvider, $urlRouterProvider, $ionicConfigProvider) {

    // Ionic uses AngularUI Router which uses the concept of states
    // Learn more here: https://github.com/angular-ui/ui-router
    // Set up the various states which the app can be in.
    // Each state's controller can be found in controllers.js

    $ionicConfigProvider.navBar.alignTitle('center');
    $ionicConfigProvider.views.transition('android');
    $ionicConfigProvider.backButton.previousTitleText(false);
    $ionicConfigProvider.backButton.icon('ion-chevron-left');
    $ionicConfigProvider.backButton.text('')


    $stateProvider

        .state('landing', {
            cache: false,
            url: '/landing',
            templateUrl: 'templates/landing.html',
            controller: 'SignInCtrl'
        })
        .state('login', {
            cache: false,
            url: '/login',
            templateUrl: 'templates/login.html',
            controller: 'SignInCtrl'
        })
        .state('terms', {
            cache: false,
            url: '/terms',
            templateUrl: 'templates/terms_and_conditions.html',
            controller: 'SignInCtrl'
        })
        .state('signUp', {
            url: '/sign-up',
            templateUrl: 'templates/sign-up.html',
            controller: 'SignInCtrl'
        })
         
        .state('verifyOTPNo', {
            cache: false,
            url: '/verifyOTPNo',
            templateUrl: 'templates/verify-otp.html',
            controller: 'SignInCtrl'
        })
        .state('profile', {
            cache: false,
            url: '/profile',
            templateUrl: 'templates/profile.html',
            controller: 'profileCtrl'
        })
        .state('dashboard', {
            cache: false,
            url: '/dashboard',
            templateUrl: 'templates/dashboard.html',
            controller: 'HomeCtrl'
        })
        .state('rate-card', {
            cache: false,
            url: '/rate-card',
            templateUrl: 'templates/rate-card.html',
            controller: 'HomeCtrl'
        })
        .state('assigned-duty', {
            cache: false,
            url: '/assigned-duty',
            templateUrl: 'templates/assigned-duties.html',
            controller: 'HomeCtrl'
        })
        .state('today_duty_invite', {
            cache: false,
            url: '/today_duty_invite',
            templateUrl: 'templates/today_duty_invite.html',
            controller: 'HomeCtrl'
        })
        .state('tomorrow_duty_invites', {
            cache: false,
            url: '/tomorrow_duty_invites',
            templateUrl: 'templates/tomorrow_duty_invites.html',
            controller: 'HomeCtrl'
        })
        .state('localduties', {
            cache: false,
            url: '/localduties',
            templateUrl: 'templates/localduties.html',
            controller: 'HomeCtrl'
        })
        .state('outstationduties', {
            cache: false,
            url: '/outstationduties',
            templateUrl: 'templates/outstationduties.html',
            controller: 'HomeCtrl'
        })
        .state('recharge', {
            cache: false,
            url: '/recharge',
            templateUrl: 'templates/recharge.html',
            controller: 'HomeCtrl'
        })
        .state('AccountSummary', {
            cache: false,
            url: '/AccountSummary',
            templateUrl: 'templates/AccountSummary.html',
            controller: 'HomeCtrl'
        })
        .state('current-duty', {
            cache: false,
            url: '/current-duty',
            templateUrl: 'templates/current-duty.html',
            controller: 'HomeCtrl'
        })
        .state('accept-cash', {
            cache: false,
            url: '/accept-cash',
            templateUrl: 'templates/accept-cash.html',
            controller: 'HomeCtrl'
        })
        .state('driverJobs', {
            cache: false,
            url: '/driverJobs',
            templateUrl: 'templates/driverJobs.html',
            controller: 'HomeCtrl'
        });
    // if none of the above states are matched, use this as the fallback
    $urlRouterProvider.otherwise('/landing');

});
