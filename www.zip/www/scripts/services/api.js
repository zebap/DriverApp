'use strict';
/**
 * @ngdoc function
 * @name conServices:api
 * @description
 * # API
 * Service of the app
 */
angular.module('conServices', [])
    .factory('API', function($rootScope, $http, $ionicLoading, $window) {

        $rootScope.show = function(text) {

            var msg;
            if (angular.isUndefined(text) || text === null) {
                msg = 'Loading...';
            } else {
                msg = text;
            }
            
            $ionicLoading.show({
                noBackdrop: false,
                animation: 'fade-in',
                showDelay: 0,
                template: '<ion-spinner icon="android"></ion-spinner>'
            });
            
        };

        $rootScope.hide = function() {
            $ionicLoading.hide();
        };

       /* $rootScope.logout = function() {
            $rootScope.setToken('');
        };

        $rootScope.notify = function(text) {
            $rootScope.show(text);
            $window.setTimeout(function() {
                $rootScope.hide();
            }, 1999);
        };*/

         return true;
        
    });